# Container, Grid, Col

The Swiss grid: 4 columns on a phone, 8 on a tablet, 12 on a desktop. Every page is built from these three.

```tsx
<Container>
  <Grid gapY={6}>
    <Col span={{ lg: 3 }}>
      <Eyebrow index="01">Selected work</Eyebrow>
    </Col>
    <Col span={{ lg: 9 }}>
      <Heading level={2}>Games for the browser.</Heading>
    </Col>
  </Grid>
</Container>
```

- `Container`: page margins (`--glow-margin`) and max width (`--glow-container`, 1360px).
- `Grid`: 4 columns at base, 8 at md, 12 at lg, with the system gutter. Change them with `columns`.
- `Col`: `span` (a number or `'full'`), `start` (1-based column line), `align`. Without `span`, a Col fills the row.

## Columns per breakpoint

| Breakpoint | Width | Columns | Token |
| --- | --- | --- | --- |
| `base` | < 768px | 4 | `--glow-cols` |
| `md` | ≥ 768px | 8 | `--glow-cols-md` |
| `lg` | ≥ 1100px | 12 | `--glow-cols-lg` |

A span counts columns of the grid at that breakpoint, so the same number means a different width at each one: `2` is half the row at base, a quarter at md and a sixth at lg. Halves and quarters exist at every breakpoint. Thirds exist only at lg.

- **One grid:** pass `columns`. A breakpoint you leave out takes the value of the one below it, so `columns={6}` is 6 everywhere and `columns={{ base: 4, md: 12 }}` is 12 at md and lg.
- **The whole site:** set the tokens on `:root` in your own CSS, after `glow-ui/styles.css`.

```css
:root {
  --glow-cols-md: 12; /* thirds on tablets too */
}
```

A span wider than the grid fills the row, so `span={12}` is always full width. A `start` past the last column also fills the row, and a `start` that leaves too little room shortens the span to the end of the row. Nothing ever adds columns the grid doesn't have.

## Responsive props

A plain value applies everywhere. `{ base, md, lg }` changes it at md ≥ 768px and lg ≥ 1100px. A breakpoint you leave out inherits the one below it. Because the column count changes too, give each breakpoint where the width should change its own value.

```tsx
<Col span={{ base: 2, md: 4, lg: 6 }}>…</Col>   {/* half the row at every size */}
<Col span={{ md: 4, lg: 3 }}>…</Col>   {/* 1 → 2 → 4 per row */}
<Col span={{ lg: 8 }} start={{ lg: 5 }}>…</Col>   {/* pushed right on desktop */}
```

Three per row on a tablet needs thirds, which 8 columns don't have. Give that grid 12 columns from md:

```tsx
<Grid columns={{ base: 4, md: 12 }}>
  <Col span={{ md: 4 }}>…</Col>
  <Col span={{ md: 4 }}>…</Col>
  <Col span={{ md: 4 }}>…</Col>
</Grid>
```

## When to use

- Labels in a narrow column, content in a wide one: `3 + 9` or `2 + 10` on `lg`, full width below it.
- On phones, leave `span` out (full width) unless items are genuinely small (badges, stats): then `2` puts two in a row.
- Use `start` to leave empty columns. Asymmetry and white space are the point of the Swiss grid.
- `Section` around a `Container` gives consistent vertical rhythm between page sections.
- `Stack` (column) and `Inline` (wrapping row) for arrangements inside a column. Don't nest a `Grid` just to put two buttons side by side.
- Spacing (`gap`, `gapX`, `gapY`) is a multiple of 8px: `gapY={6}` is 48px. A string such as `'2rem'` is used as is.
- `Grid as="ol"` with `stagger` makes a semantic list whose items animate in turn.

## Header bar

A header is the exception to full width on phones: the wordmark and the nav share one row on a phone too. Split it `2 + 2` on `base` so three short links fit at 390px, and align the nav to the right edge with `Inline`.

```tsx
<Container as="header">
  <Grid align="baseline">
    <Col span={{ base: 2, md: 6, lg: 9 }}>
      <a href="/" className="wordmark">Wordmark</a>
    </Col>
    <Col span={{ base: 2, md: 2, lg: 3 }}>
      <Inline
        as="nav"
        aria-label="Sections"
        justify="flex-end"
        gap={3}
        style={{ fontSize: 'var(--glow-fs-text-sm)' }}
      >
        <a className="glow-link" href="#work">Work</a>
        <a className="glow-link" href="#about">About</a>
        <a className="glow-link" href="#contact">Contact</a>
      </Inline>
    </Col>
  </Grid>
  <Rule tone="hairline" />
</Container>
```

- Header links are set smaller than body text, at `--glow-fs-text-sm` (14px). The size goes on the nav, and the `glow-link`s inherit it.
- Keep the nav to a few short words. If it doesn't fit at 390px, shorten the labels or move the nav to its own row (leave `base` out of both spans) rather than shrinking the type.
- Leave `Inline` wrapping (the default). With `wrap={false}`, links that don't fit run off the edge and cause a horizontal scroll.

## Checking the layout

`GridOverlay` with `useGridToggle('g')` draws the columns as glowing lines, 4, 8 or 12 depending on the width. Press G to toggle it. Give it the same `columns` as a Grid that sets its own.

```tsx
const [grid] = useGridToggle('g');
<GridOverlay visible={grid} />
```

## Props

### Container

<!-- props:Container -->
| Prop | Type | Default | Description |
| --- | --- | --- | --- |
| `reveal` | `RevealProp` |  | Animate in when scrolled into view. |
| `stagger` | `StaggerProp` |  | Animate direct children one after another (true = 80ms apart, or a number of ms). |
| `as` | `ElementType` | `'div'` | The element to render, e.g. `'section'`, `'ul'`, `'ol'`. |

`className` and `style` are passed to the root element. Also accepts the standard HTML attributes of the rendered element.

`RevealProp`, `StaggerProp`: see [motion/reveal.md](../motion/reveal.md).
<!-- /props -->

### Grid

<!-- props:Grid -->
| Prop | Type | Default | Description |
| --- | --- | --- | --- |
| `columns` | `Responsive<number>` | `--glow-cols` 4 · `--glow-cols-md` 8 · `--glow-cols-lg` 12 | Number of columns. Responsive: a breakpoint you leave out takes the value of the one below it, and a single number applies to all three. |
| `gap` | `Space` | `--glow-gutter` (16–24px) | Gap between columns and between rows. |
| `gapX` | `Space` |  | Gap between columns only. Overrides `gap`. |
| `gapY` | `Space` |  | Gap between rows only. Overrides `gap`. |
| `align` | `CSSProperties['alignItems']` |  | Vertical alignment of items in their row: `'start'`, `'center'`, `'end'`, `'baseline'` or `'stretch'` (CSS `align-items`). |
| `reveal` | `RevealProp` |  | Animate in when scrolled into view. |
| `stagger` | `StaggerProp` |  | Animate direct children one after another (true = 80ms apart, or a number of ms). |
| `as` | `ElementType` | `'div'` | The element to render, e.g. `'section'`, `'ul'`, `'ol'`. |

`className` and `style` are passed to the root element. Also accepts the standard HTML attributes of the rendered element.

Types used above:

```ts
type Responsive<T> = T | Partial<Record<Breakpoint, T>>;

/** Spacing: a number is a multiple of the 8px unit; a string is used as-is. */
type Space = number | string;

type Breakpoint = 'base' | 'md' | 'lg';
```

`RevealProp`, `StaggerProp`: see [motion/reveal.md](../motion/reveal.md).
<!-- /props -->

### GridOverlay

<!-- props:GridOverlay -->
| Prop | Type | Default | Description |
| --- | --- | --- | --- |
| `visible` | `boolean` | required | Show the overlay. Usually the state from `useGridToggle`. |
| `columns` | `Responsive<number>` | `--glow-cols` 4 · `--glow-cols-md` 8 · `--glow-cols-lg` 12 | Match this to the Grid you're checking. Responsive, like `Grid columns`. |
| `baseline` | `boolean` | `true` | Also draw baseline rows (every --glow-baseline). |
<!-- /props -->

### Col

<!-- props:Col -->
| Prop | Type | Default | Description |
| --- | --- | --- | --- |
| `span` | `Responsive<number \| 'full'>` | `'full'` | Columns to span, or `'full'` for the whole row. Responsive: `span={{ md: 4, lg: 3 }}`. A span wider than the grid fills the row. |
| `start` | `Responsive<number>` |  | Column line to start on (1-based), leaving the columns before it empty. Responsive. Without it, columns flow left to right. A start past the last column fills the row. |
| `align` | `CSSProperties['alignSelf']` |  | Vertical alignment of this item in its row, overriding the Grid's `align` (CSS `align-self`). |
| `reveal` | `RevealProp` |  | Animate in when scrolled into view. |
| `stagger` | `StaggerProp` |  | Animate direct children one after another (true = 80ms apart, or a number of ms). |
| `as` | `ElementType` | `'div'` | The element to render, e.g. `'section'`, `'ul'`, `'ol'`. |

`className` and `style` are passed to the root element. Also accepts the standard HTML attributes of the rendered element.

`RevealProp`, `StaggerProp`: see [motion/reveal.md](../motion/reveal.md).
<!-- /props -->
