# Theming

Glow UI is themed with CSS custom properties (tokens). Override them on `:root` for the whole site, or on an element for one part of it.

```css
:root {
  --glow-h: 268;                              /* violet everything */
  --glow-fs-display: clamp(40px, 8vw, 112px); /* a calmer hero */
  --glow-reveal-offset: 15%;                  /* reveal a little earlier */
}
```

## Color

Every color is derived from one hue, `--glow-h` (0–360). Never hard-code a color in a component.

```tsx
<div className="glow-hue" style={{ '--glow-h': 150 } as React.CSSProperties}>…</div>  {/* green subtree */}
<Card hue={320}>…</Card>                                                             {/* shorthand */}
<div className="glow-danger">…</div>                                                  {/* 352, red */}
```

`--glow-h` only retints on `:root` or on an element with `glow-hue`, `glow-danger` (352), `glow-success` (152) or `glow-warning` (38), because that's where the derived colors are recalculated.

## Light and dark

The dark glow theme is the default. The light theme is the same system on paper: the same sizes, spacing, radii and type, so nothing moves when the theme switches. Only color and shadow change.

- **Attention** is the accent color instead of glow: what is focused, open, checked or primary gets an accent edge, fill or label. Resting controls stay ink on paper. `glow-lit` and `glow-lit-sm` give an accent edge, and `--glow-shadow` / `--glow-shadow-sm` are `none`.
- **Shadows** are only for floating layers (popovers, tooltips, the dialog), to separate them from the page.
- **Focus** is a tinted ring (an outline), so a focused control never looks selected.
- **Colors** still come from `--glow-h`. The light tokens are `--glow-paper`, `--glow-ink` and the accent `--glow-spot`.

### Setting the theme yourself

`data-glow-theme="light"` on any element switches its subtree, the same way `--glow-h` retints one. On `<html>` it switches the page. `"dark"` or no attribute is the dark theme. A dark section inside a light page isn't supported yet: `data-glow-theme="dark"` on an element inside a light one has no effect.

### Following the visitor

`useTheme` follows the visitor's system setting (`prefers-color-scheme`) until they choose a theme, remembers the choice in `localStorage` (key `glow-theme`), and sets `data-glow-theme` on `<html>`. Every component that calls it stays in sync, and so do other tabs.

```tsx
import { useTheme } from 'glow-ui';

function ThemeSelect() {
  const { theme, setTheme } = useTheme();
  return (
    <Select
      label="Theme"
      value={theme}
      onChange={setTheme}
      options={[
        { value: 'system', label: 'System' },
        { value: 'light', label: 'Light' },
        { value: 'dark', label: 'Dark' },
      ]}
    />
  );
}
```

React runs after the first paint, so on its own `useTheme` would show a light-mode visitor the dark theme for a moment. A small script in `<head>` applies the theme before anything is drawn. Where it goes depends on how the page is rendered.

**Client-only apps (Vite, plain `index.html`).** Paste this into `<head>` in `index.html`, before your stylesheets and your app's script. It's ordinary HTML, no React involved:

```html
<script>(function(){var t;try{t=localStorage.getItem('glow-theme')}catch(e){}if(t!=='light'&&t!=='dark')t=matchMedia('(prefers-color-scheme: light)').matches?'light':'dark';document.documentElement.setAttribute('data-glow-theme',t)})()</script>
```

It is the `themeScript` export as a string. When you upgrade, check the changelog for changes to it.

**Server-rendered React (Next.js, Remix, …).** Render `<ThemeScript />` in `<head>`. It outputs the same script inline. Pass `nonce` if your Content Security Policy requires one for inline scripts.

```tsx
import { ThemeScript } from 'glow-ui';

<head>
  <ThemeScript />
</head>
```

Don't render `<ThemeScript />` in a client-only app: browsers never run a `<script>` that React inserts after the page has loaded.

<!-- props:ThemeScript -->
| Prop | Type | Default | Description |
| --- | --- | --- | --- |
| `nonce` | `string` |  | The nonce your Content Security Policy requires for inline scripts, if it has one. |
<!-- /props -->

Without `useTheme` and the script, the page stays dark unless you set `data-glow-theme` yourself.

What `useTheme` returns:

<!-- props:ThemeState -->
| Prop | Type | Default | Description |
| --- | --- | --- | --- |
| `theme` | `ThemeChoice` | required | What the visitor chose. `system` follows the operating system's light or dark mode. |
| `resolved` | `ResolvedTheme` | required | The theme on screen now: `theme`, or the system's mode when `theme` is `system`. |
| `setTheme` | `(theme: ThemeChoice) => void` | required | Change the theme. The choice is saved in `localStorage`, so it applies on the next visit too. `system` clears it. |

Types used above:

```ts
/** A visitor's theme choice. `system` follows the operating system's light or dark mode. */
type ThemeChoice = 'system' | 'light' | 'dark';

/** The theme actually on screen. */
type ResolvedTheme = 'light' | 'dark';
```
<!-- /props -->

## Using the glow yourself

For a custom element in an attention state (focused, selected, primary), use the same glow as the components:

- Classes: `glow-surface` (frosted glass panel), `glow-lit` (full neon edge and halo), `glow-lit-sm` (tight glow), `glow-sweep` (a streak of light travelling around the border), `glow-link` (a quiet text link, see [type/links.md](type/links.md)).
- Tokens: `box-shadow: var(--glow-shadow)` or `var(--glow-shadow-sm)`, and `var(--glow-line)` / `var(--glow-core)` for a neon line color.

Other `glow-*` classes and all `@keyframes` are internal and can change in any release.

## Tokens

Generated from `styles.css`. The defaults are what you get without overriding anything.

<!-- tokens -->
**Color, fonts and shape**

| Token | Default |
| --- | --- |
| `--glow-h` | `218` |
| `--glow-font` | `'Inter', ui-sans-serif, system-ui, -apple-system, 'Segoe UI', sans-serif` |
| `--glow-font-display` | `'Inter Tight', 'Helvetica Neue', Helvetica, Arial, sans-serif` |
| `--glow-radius` | `18px` |
| `--glow-radius-md` | `12px` |
| `--glow-radius-sm` | `8px` |
| `--glow-bg` | `#000` |
| `--glow-ease` | `cubic-bezier(0.2, 0.9, 0.25, 1)` |
| `--glow-ease-out` | `cubic-bezier(0.16, 1, 0.3, 1)` |

**Light theme (data-glow-theme="light"): the paper and the ink. The accent color comes from --glow-h.**

| Token | Default |
| --- | --- |
| `--glow-paper` | `oklch(0.965 0.008 85)` |
| `--glow-ink` | `oklch(0.19 0.012 260)` |
| `--glow-unit` | `8px` |
| `--glow-cols` | `4` |
| `--glow-cols-md` | `8` |
| `--glow-cols-lg` | `12` |
| `--glow-baseline` | `24px` |
| `--glow-gutter` | `clamp(16px, 2vw, 24px)` |
| `--glow-margin` | `clamp(16px, 5vw, 72px)` |
| `--glow-container` | `1360px` |
| `--glow-section-pad` | `clamp(64px, 10vw, 144px)` |
| `--glow-anchor-offset` | `32px` |

**Type scale: headings (Heading size) and body text (Text size)**

| Token | Default |
| --- | --- |
| `--glow-fs-display` | `clamp(48px, 9vw, 136px)` |
| `--glow-fs-xl` | `clamp(36px, 5.2vw, 76px)` |
| `--glow-fs-l` | `clamp(28px, 3.2vw, 46px)` |
| `--glow-fs-m` | `clamp(22px, 2.2vw, 30px)` |
| `--glow-fs-s` | `18px` |
| `--glow-fs-numeral` | `clamp(56px, 8vw, 128px)` |
| `--glow-fs-text-lg` | `clamp(18px, 1.6vw, 22px)` |
| `--glow-fs-text` | `16px` |
| `--glow-fs-text-sm` | `14px` |
| `--glow-fs-text-xs` | `12px` |

**Motion: content reveals once its top passes this far above the viewport bottom**

| Token | Default |
| --- | --- |
| `--glow-reveal-offset` | `25%` |
<!-- /tokens -->
