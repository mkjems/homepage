# Menu

A button that opens a list of actions.

```tsx
<Menu
  trigger={<SparkIcon />}
  icon
  aria-label="Project actions"
  align="end"
  items={[
    { label: 'Duplicate', hint: '⌘D', onSelect: duplicate },
    { label: 'Rename', onSelect: rename },
    { separator: true },
    { label: 'Delete', danger: true, onSelect: remove },
  ]}
/>
```

## When to use

- A handful of actions that would clutter the screen as separate buttons: row actions, "more" buttons, toolbars.
- For picking a value, use `Select`. For navigation, use links.
- Put destructive actions last, after a separator, with `danger`.
- An icon-only trigger (`icon`) needs an `aria-label`.
- `align="end"` when the trigger sits at the right edge, so the menu doesn't run off the page.

## States

- **Closed:** the trigger looks like a `Button` of the given `variant`.
- **Open:** the trigger dims (pressed) and the menu glows. It grows in from the trigger.
- **Active item:** highlighted under the pointer or keyboard. Disabled items are dimmed and skipped.

## Accessibility

Handled for you: `menu` / `menuitem` roles, `aria-haspopup`, `aria-expanded`, `aria-activedescendant`. Keys: ↓ or ↑ on the trigger opens it at the first or last item, ↑ ↓ Home End move, Enter or Space runs the item, Esc closes and returns focus to the trigger, Tab closes.

## Known limitation

Like `Select`, the menu is positioned with CSS, so a parent with `overflow: hidden` clips it.

## Props

<!-- props:Menu -->
| Prop | Type | Default | Description |
| --- | --- | --- | --- |
| `items` | `MenuItem[]` | required | Actions; insert `{ separator: true }` to draw a divider. |
| `trigger` | `ReactNode` | required | Content of the trigger button. |
| `aria-label` | `string` |  | Required when the trigger is icon-only. |
| `variant` | `ButtonVariant` | `'quiet'` | Look of the trigger button. See Button. |
| `size` | `ButtonSize` | `'md'` | Size of the trigger button. |
| `icon` | `boolean` | `false` | Square icon-only trigger. |
| `align` | `'start' \| 'end'` | `'start'` | Which edge of the trigger the menu lines up with. Use `end` at the right edge of the page. |

`className` is passed to the root element.

Types used above:

```ts
type MenuItem = MenuAction | Separator;

type ButtonVariant = 'glow' | 'quiet' | 'outline' | 'ghost';

type ButtonSize = 'sm' | 'md' | 'lg';

interface MenuAction {
  label: ReactNode;
  /** Secondary text on the right, e.g. a shortcut like "⌘D". */
  hint?: ReactNode;
  /** Icon before the label. */
  icon?: ReactNode;
  /** Called when the item is chosen. The menu has already closed. */
  onSelect?: () => void;
  disabled?: boolean;
  /** Tints the item red, for destructive actions like Delete. */
  danger?: boolean;
}

type Separator = { separator: true };
```
<!-- /props -->
