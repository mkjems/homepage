# Select

Choose one value from a list. A custom listbox that grows open with a glowing edge.

```tsx
<Select
  label="Viewport"
  defaultValue="tablet"
  options={[
    { value: 'tablet', label: 'Tablet', hint: '810' },
    { value: 'phone', label: 'Phone', hint: '390' },
    { separator: true },
    { value: 'custom', label: 'Custom…', disabled: true },
  ]}
  onChange={(value) => setViewport(value)}
/>
```

Controlled: pass `value` and `onChange`. Uncontrolled: pass `defaultValue`.

## When to use

- One choice from about 3–15 options. For 2–4 options that should all be visible, use `RadioGroup` or `Tabs`.
- For actions rather than a value ("Duplicate", "Delete"), use `Menu`.
- `variant="ghost"` for a select inside a sentence or a toolbar, with just text and a chevron.
- `align="end"` when the select sits at the right edge, so the list lines up with it.
- Use `hint` for secondary info on the right (sizes, shortcuts). Use `{ separator: true }` to group options.
- In a form, pass `name`. A hidden input submits the value.
- Type the values for safer `onChange`: `Select<'tablet' | 'phone'>`.

## States

- **Resting:** quiet frosted pill.
- **Focused / open:** the trigger and list glow. The list grows in from the trigger.
- **Active option:** highlighted, the selected option has a check mark.
- **Disabled:** dimmed, doesn't open.

## Accessibility

Handled for you: `combobox` + `listbox` roles, `aria-expanded`, `aria-activedescendant`. Keys: ↑ ↓ Home End to move, Enter or Space to choose, Esc to close, Tab to leave, and typing letters jumps to a matching option.

You provide: a `label`, or an `aria-label` when there's no visible label. If an option's `label` isn't plain text, set `textValue` so type-ahead works.

## Known limitation

The list is positioned with CSS, not a portal, so a parent with `overflow: hidden` clips it. Keep selects out of clipped containers (planned fix: 0.4.0).

## Props

<!-- props:Select -->
| Prop | Type | Default | Description |
| --- | --- | --- | --- |
| `options` | `SelectItem<string>[]` | required | Options; insert `{ separator: true }` to draw a divider. |
| `value` | `string \| null` |  | The selected value, for a controlled select. `null` shows the placeholder. Use with `onChange`. |
| `defaultValue` | `string \| null` |  | The initially selected value, for an uncontrolled select. |
| `onChange` | `(value: string) => void` |  | Called with the new value when the user picks an option. |
| `placeholder` | `ReactNode` | `'Select…'` | Shown while no value is selected. |
| `label` | `ReactNode` |  | Visible label above the select. Without it, pass `aria-label`. |
| `variant` | `'field' \| 'ghost'` | `'field'` | `field` frosted pill (default) or `ghost`: just text and a chevron. |
| `align` | `'start' \| 'end'` | `'start'` | Which edge the menu lines up with. |
| `disabled` | `boolean` | `false` | Dimmed and can't be opened. |
| `name` | `string` |  | Renders a hidden input so the value is submitted with a form. |
| `id` | `string` |  | id of the trigger button, e.g. for an external `<label htmlFor>`. Generated if left out. |
| `aria-label` | `string` |  | Accessible name when there's no visible `label`. |

`className` and `style` are passed to the root element.

Types used above:

```ts
type SelectItem<V extends string = string> = SelectOption<V> | Separator;

interface SelectOption<V extends string = string> {
  value: V;
  label: ReactNode;
  /** Secondary text on the right, e.g. "810". */
  hint?: ReactNode;
  disabled?: boolean;
  /** Text used for type-ahead when `label` is not a plain string. */
  textValue?: string;
}

type Separator = { separator: true };
```
<!-- /props -->
