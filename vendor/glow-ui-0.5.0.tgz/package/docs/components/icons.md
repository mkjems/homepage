# Icons

The small set of line icons the components use, exported for your own buttons.

```tsx
import { PlusIcon, SearchIcon } from 'glow-ui';

<Button icon aria-label="Add"><PlusIcon /></Button>
<Input label="Search" leading={<SearchIcon />} />
```

Available: `ArrowUpIcon`, `CheckIcon`, `ChevronDownIcon`, `CloseIcon`, `PlusIcon`, `PointerIcon`, `SearchIcon`, `SparkIcon`.

## When to use

- Inside `Button icon`, `Menu` items and Input `leading` / `trailing`, which size them for you. Elsewhere, pass `width` and `height` (they're plain SVGs on a 24×24 grid and accept any SVG attribute).
- They draw in the current text color.
- For anything else, use your own icon set. These aren't meant to grow into a full library.

## Accessibility

The icons are `aria-hidden`. Name the control that contains them with an `aria-label` or visible text.
