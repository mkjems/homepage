# Tooltip

A short label that appears on hover and keyboard focus.

```tsx
<Tooltip content="Add project">
  <Button icon aria-label="Add project"><PlusIcon /></Button>
</Tooltip>
```

## When to use

- To name an icon-only button, or add a keyboard shortcut ("Search ⌘K").
- A few words, no links or buttons inside. Anything longer or interactive belongs on the page or in a `Dialog`.
- Don't put essential information only in a tooltip: touch screens have no hover.
- `placement="bottom"` when the trigger is near the top of the viewport.

## States

- **Hover:** appears after `delay` (200ms), so it doesn't flash while the pointer passes.
- **Keyboard focus:** appears immediately.
- **Esc, blur or pointer leave:** hides.

## Accessibility

The trigger gets `aria-describedby` pointing to the tooltip while it's shown. The child must be a single focusable element (a `Button`, a link) so keyboard users can reach it. A tooltip describes, it doesn't name: an icon-only button still needs its own `aria-label`.

## Known limitation

Positioned with CSS, so a parent with `overflow: hidden` clips it.

## Props

<!-- props:Tooltip -->
| Prop | Type | Default | Description |
| --- | --- | --- | --- |
| `content` | `ReactNode` | required | What the tooltip says. Keep it to a short phrase. |
| `children` | `ReactElement` | required | A single focusable element (e.g. a Button). |
| `placement` | `'top' \| 'bottom'` | `'top'` | Show above or below the trigger. |
| `delay` | `number` | `200` | Delay in ms before showing on hover. |
<!-- /props -->
