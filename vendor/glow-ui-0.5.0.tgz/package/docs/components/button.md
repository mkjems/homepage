# Button

An action, or a link that looks like one.

```tsx
<Button variant="glow">Publish</Button>
<Button variant="outline" href="/games">Play →</Button>
<Button variant="ghost" size="sm" onClick={close}>Cancel</Button>
<Button icon aria-label="Add"><PlusIcon /></Button>
```

## When to use

- `glow`: the one primary action in a view. Only one per screen or dialog.
- `quiet` (default): ordinary actions.
- `outline`: secondary calls to action, often links such as "Play →" or "Read more".
- `ghost`: low-emphasis actions next to a primary one, like Cancel in a dialog, or in toolbars.
- Sizes: `sm` in dense UI and toolbars, `md` by default, `lg` for a hero call to action.
- If it navigates, pass `href`. It renders an `<a>` with the same look and accepts `target`, `rel` and other anchor attributes.
- Don't write `<a className="glow-btn glow-btn--outline">`. Use `<Button variant="outline" href="…">`.

## States

| State | `glow` | `outline` | `quiet` / `ghost` |
| --- | --- | --- | --- |
| Resting | small glow | faint neon edge | glass / text only |
| Hover | full glow | small glow | lighter glass |
| Keyboard focus | small glow ring | small glow ring | small glow ring |
| Disabled | dimmed to 45%, no glow | same | same |

## Accessibility

- Renders a native `<button type="button">`, so pass `type="submit"` explicitly in forms.
- An `icon` button has no visible text: always give it an `aria-label`.
- With `href` it's a real link, so it opens in a new tab and works with the keyboard and screen readers as one.

## Props

<!-- props:Button -->
| Prop | Type | Default | Description |
| --- | --- | --- | --- |
| `href` | `string` |  | Renders an `<a>` with the same look. Use it whenever the button navigates. |
| `variant` | `ButtonVariant` | `'quiet'` | `glow` solid neon, `quiet` frosted glass, `outline` neon edge, `ghost` text only. |
| `size` | `ButtonSize` | `'md'` | `sm` for dense UI and toolbars, `md` for most buttons, `lg` for a hero call to action. |
| `icon` | `boolean` | `false` | Square button for a single icon. Give it an `aria-label`. |

`className` and `style` are passed to the root element. Also accepts the standard HTML attributes of `<button>` or `<a>` (with `href`).

Types used above:

```ts
type ButtonVariant = 'glow' | 'quiet' | 'outline' | 'ghost';

type ButtonSize = 'sm' | 'md' | 'lg';
```
<!-- /props -->
