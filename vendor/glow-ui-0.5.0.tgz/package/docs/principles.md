# Principles

Five rules that every Glow UI page follows. Read these before the component pages.

## 1. Glow means attention

Resting controls are quiet frosted glass. The neon edge and halo appear only on what has attention: focused, open, checked, or the primary action.

- One `variant="glow"` button per view. Everything else is `quiet`, `outline` or `ghost`.
- Use `Card glow="full"` for the one thing you want noticed, not for every card.
- Don't add glow with your own `box-shadow`. If you need it on a custom element, use the `glow-lit` / `glow-lit-sm` classes or the `--glow-shadow` / `--glow-shadow-sm` tokens, and only for an attention state.

## 2. Every color comes from one hue

`--glow-h` (default `218`, blue) drives every color. Never hard-code a color.

```tsx
<div className="glow-hue" style={{ '--glow-h': 150 } as React.CSSProperties}>…</div>  {/* green subtree */}
<Card hue={320}>…</Card>                                                             {/* shorthand */}
<div className="glow-danger">…</div>                                                  {/* also glow-success, glow-warning */}
```

Setting `--glow-h` on a plain element does nothing. It has to be `:root` or an element with `glow-hue` or a tone class.

## 3. Layout is the 12-column grid

Pages are `Container` → `Grid` → `Col`. Responsive props take `{ base, md, lg }` (md ≥ 768px, lg ≥ 1100px). See [layout/grid.md](layout/grid.md).

Spacing props are multiples of 8px: `gap={3}` is 24px.

## 4. Motion is a prop, not code

Layout and type components take `reveal` and `stagger`. `RevealText` animates headlines. Content reveals when it is about a quarter of the way up the viewport, and with `prefers-reduced-motion` it just appears. See [motion/reveal.md](motion/reveal.md).

```tsx
<Grid reveal="rise" stagger={120}>…</Grid>
<Text reveal={{ effect: 'blur', delay: 400 }}>…</Text>
```

Reveal sparingly: a page where everything animates draws attention to nothing.

## 5. Only some CSS is public

You can rely on (all listed in [theming.md](theming.md)):

- Components and their props.
- Tokens at the top of `styles.css`: `--glow-h`, `--glow-font`, `--glow-font-display`, `--glow-radius*`, `--glow-bg`, `--glow-fs-*`, `--glow-reveal-offset`, `--glow-shadow`, `--glow-shadow-sm`.
- Utility classes: `glow-root`, `glow-hue`, `glow-danger` / `glow-success` / `glow-warning`, `glow-surface`, `glow-lit`, `glow-lit-sm`, `glow-sweep`.

Every other `glow-*` class and every `@keyframes` is internal and can change in any release. Don't write `<a className="glow-btn">` (use `<Button href>`), and don't copy keyframes such as `glow-rise` (use `reveal`).

## Setup, once per app

```tsx
import 'glow-ui/fonts.css';   // optional: Inter + Inter Tight via @fontsource
import 'glow-ui/styles.css';

<body className="glow-root">  {/* black background, font, text color */}
```
