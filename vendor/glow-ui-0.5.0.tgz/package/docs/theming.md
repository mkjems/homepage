# Theming

Glow UI is themed with CSS custom properties (tokens). Override them on `:root` for the whole site, or on an element for one part of it.

```css
:root {
  --glow-h: 268;                              /* violet everything */
  --glow-fs-display: clamp(40px, 8vw, 112px); /* a calmer hero */
  --glow-reveal-offset: 15%;                  /* reveal a little earlier */
}
```

## Color

Every color is derived from one hue, `--glow-h` (0–360). Never hard-code a color in a component.

```tsx
<div className="glow-hue" style={{ '--glow-h': 150 } as React.CSSProperties}>…</div>  {/* green subtree */}
<Card hue={320}>…</Card>                                                             {/* shorthand */}
<div className="glow-danger">…</div>                                                  {/* 352, red */}
```

`--glow-h` only retints on `:root` or on an element with `glow-hue`, `glow-danger` (352), `glow-success` (152) or `glow-warning` (38), because that's where the derived colors are recalculated.

There is no light theme yet: the system is designed for a black background (`--glow-bg`).

## Using the glow yourself

For a custom element in an attention state (focused, selected, primary), use the same glow as the components:

- Classes: `glow-surface` (frosted glass panel), `glow-lit` (full neon edge and halo), `glow-lit-sm` (tight glow), `glow-sweep` (a streak of light travelling around the border), `glow-link` (a quiet text link, see [type/links.md](type/links.md)).
- Tokens: `box-shadow: var(--glow-shadow)` or `var(--glow-shadow-sm)`, and `var(--glow-line)` / `var(--glow-core)` for a neon line color.

Other `glow-*` classes and all `@keyframes` are internal and can change in any release.

## Tokens

Generated from `styles.css`. The defaults are what you get without overriding anything.

<!-- tokens -->
**Color, fonts and shape**

| Token | Default |
| --- | --- |
| `--glow-h` | `218` |
| `--glow-font` | `'Inter', ui-sans-serif, system-ui, -apple-system, 'Segoe UI', sans-serif` |
| `--glow-font-display` | `'Inter Tight', 'Helvetica Neue', Helvetica, Arial, sans-serif` |
| `--glow-radius` | `18px` |
| `--glow-radius-md` | `12px` |
| `--glow-radius-sm` | `8px` |
| `--glow-bg` | `#000` |
| `--glow-ease` | `cubic-bezier(0.2, 0.9, 0.25, 1)` |
| `--glow-ease-out` | `cubic-bezier(0.16, 1, 0.3, 1)` |
| `--glow-unit` | `8px` |
| `--glow-baseline` | `24px` |
| `--glow-gutter` | `clamp(16px, 2vw, 24px)` |
| `--glow-margin` | `clamp(16px, 5vw, 72px)` |
| `--glow-container` | `1360px` |
| `--glow-section-pad` | `clamp(64px, 10vw, 144px)` |
| `--glow-anchor-offset` | `32px` |

**Type scale: headings (Heading size) and body text (Text size)**

| Token | Default |
| --- | --- |
| `--glow-fs-display` | `clamp(48px, 9vw, 136px)` |
| `--glow-fs-xl` | `clamp(36px, 5.2vw, 76px)` |
| `--glow-fs-l` | `clamp(28px, 3.2vw, 46px)` |
| `--glow-fs-m` | `clamp(22px, 2.2vw, 30px)` |
| `--glow-fs-s` | `18px` |
| `--glow-fs-numeral` | `clamp(56px, 8vw, 128px)` |
| `--glow-fs-text-lg` | `clamp(18px, 1.6vw, 22px)` |
| `--glow-fs-text` | `16px` |
| `--glow-fs-text-sm` | `14px` |
| `--glow-fs-text-xs` | `12px` |

**Motion: content reveals once its top passes this far above the viewport bottom**

| Token | Default |
| --- | --- |
| `--glow-reveal-offset` | `25%` |
<!-- /tokens -->
