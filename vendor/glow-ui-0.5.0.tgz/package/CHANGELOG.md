# Changelog

All notable changes to Glow UI. Glow UI is pre-1.0: a minor version (0.x.0) can contain breaking or visible changes, a patch (0.x.y) only fixes. Planned releases are in `ROADMAP.md`.

## 0.5.0

Quiet text links, and finer control over section spacing.

### Added

- `glow-link`: a class for text links in navs, footers and running text. It is muted with no underline at rest, and glows with `--glow-core` and a `--glow-line` halo on hover and keyboard focus, where it also gets a thin outline. Works on `<button>` too, for text-style actions. A tone class on the same element changes the resting color. Inside a `<p>` or `Text`, it keeps the text color and gets a hairline underline. See `docs/type/links.md`.
- `Section padding={{ top, bottom }}` sets each side separately. A side you leave out keeps the default. A single value still sets both.
- `--glow-section-pad` token: the default section padding, `clamp(64px, 10vw, 144px)`.
- `--glow-anchor-offset` token (`32px`): a `#link` to a `Section` stops this far below the top edge, not flush against it.

### Changed

- `Section` has `scroll-margin-top: var(--glow-anchor-offset)`, so links to its `id` no longer land flush against the top of the window.
- `docs/layout/section.md`: one page-wide `Container` with plain `Section`s inside also works.

### Migrating from 0.4.1

- Install `glow-ui-0.5.0.tgz` from `versions/`. Nothing in your code needs to change.
- Hand-written styles for quiet nav and footer links can become `className="glow-link"`.
- Hand-written `padding-block` and `scroll-margin-top` around sections can become `Section` with `padding={{ top, bottom }}`.

## 0.4.1

Release tarballs live in a `versions/` folder.

### Changed

- `npm run pack` writes the tarball to `versions/glow-ui-<version>.tgz`, and every release is kept there. The README's install and upgrade steps use the new path.

### Migrating from 0.4.0

- Install `glow-ui-0.4.1.tgz` from `versions/`. Nothing in your code needs to change.

## 0.4.0

Headings in two tones, readable secondary text, and a way to tell which version is installed.

### Added

- `RevealText parts`: a heading built from segments that continue one stagger, each with its own tone, without starting a new row: `parts={['One small server.', { text: 'Shipped on every push.', tone: 'muted' }]}`. A part is a string or `{ text, tone?, break? }`. `break: true` starts a new row. Works with every effect, including `decode`. The element keeps a single `aria-label`.
- Exported type `RevealTextPart`.
- `version`: `import { version } from 'glow-ui'` gives the installed version.
- The shipped `styles.css` starts with a `/* glow-ui 0.4.0 */` comment.
- README: steps for upgrading a tarball kept in the repository, in an order that never leaves its folder empty.
- README: a Scope section. Glow UI is general purpose, and patterns specific to one site are left to that site.
- `docs/layout/grid.md`: a header bar recipe, a wordmark and nav that share one row at 390px.

### Changed

- Secondary text is brighter, so it meets WCAG AA (4.5:1). `--glow-text-faint` was about 2.7:1 and is now 6.7:1 on black and at least 4.7:1 on quiet and glass surfaces in every hue. The one exception is the top edge of a success or warning glass surface, where it is 3.7:1. `--glow-text-muted` was 4.1–6.3:1 and is now 9.8:1 on black and at least 5.2:1 everywhere. This affects `tone="muted"` and `tone="faint"`, help text, placeholders, checkbox descriptions, eyebrows and other secondary text.
- Hairlines are visible: `--glow-separator` goes from `/ 0.1` to `/ 0.3` alpha (about 1.1:1 to 1.8:1 on black). This affects `Rule tone="hairline"`, list and table row lines, `Divider` and menu separators.
- `RevealText` with `effect="decode"` now renders the same wrapper and `data-*` attributes as the other effects.

### Fixed

- `RevealText effect="rise"` no longer cuts the glow off `tone="glow"` text into a box around each word. Words are clipped only while they rise.

### Migrating from 0.3.1

- Install `glow-ui-0.4.0.tgz`, following the new upgrade steps in the README if the tarball lives in your repository.
- Muted text, faint text and hairlines are brighter. Nothing in your code needs to change.
- A heading built from several `RevealText`s or spans to get a second tone can become one `RevealText parts={[…]}`.

## 0.3.1

Documentation for every component, shipped in the package.

### Added

- `docs/`: usage guides for every component, shipped in the package at `node_modules/glow-ui/docs/`. Start with `docs/principles.md`; `docs/README.md` is the index, and `docs/theming.md` lists every token.
- Each page ends with a props table (type, default, description) generated from the TypeScript source, plus the definitions of the Glow UI types it uses.
- Doc comments, and `@default` where the default lives in CSS, for every public prop, so they also show up on hover in your editor.
- `CHANGELOG.md` now ships in the package.

### Changed

- `InlineProps` is an interface instead of a type alias. It accepts the same props.
- `--glow-font-display` moved next to `--glow-font` at the top of `styles.css`. Same value.

### Migrating from 0.3.0

- Install `glow-ui-0.3.1.tgz`. Nothing in your code needs to change.
- Point your AI assistant at `node_modules/glow-ui/docs/README.md`.

## 0.3.0

Calmer type and motion.

### Added

- Type scale tokens at the top of `styles.css`: `--glow-fs-display`, `--glow-fs-xl`, `--glow-fs-l`, `--glow-fs-m`, `--glow-fs-s`, `--glow-fs-numeral`, and `--glow-fs-text-lg` / `--glow-fs-text` / `--glow-fs-text-sm` / `--glow-fs-text-xs`. Override them to tune the scale.
- `--glow-reveal-offset` token (default `25%`) sets how far up the viewport content must scroll before it reveals. `useInView` reads it once per page.
- `offset` for a single element: in `reveal={{ effect, offset }}`, on `Reveal`, `RevealText`, `RevealImage`, `Rule` and `Counter`, and in `useInView` options. A number is a percentage of the viewport height, a string any length (`'120px'`).
- `RevealText lines={["Games for", "the browser."]}` puts each line on its own row and staggers through them in one sequence. Works with every effect, including `decode`.
- `glow-ui/fonts.css`: optional self-hosted Inter and Inter Tight via `@fontsource/inter` and `@fontsource/inter-tight`, which are optional peer dependencies.
- Exported types `RevealOffset` and `InViewOptions`.

### Changed

- Smaller large headings: display `clamp(48px, 9vw, 136px)` (was `clamp(56px, 11.5vw, 184px)`), xl `clamp(36px, 5.2vw, 76px)` (was `clamp(40px, 6.4vw, 96px)`), l `clamp(28px, 3.2vw, 46px)` (was `clamp(30px, 3.8vw, 56px)`). The m, s, numeral and text sizes are unchanged.
- Content reveals later: when its top is 25% above the bottom of the viewport (was 10%).
- Content near the end of the page that can never scroll that high now reveals when the page is scrolled to the bottom.
- `RevealText` `children` is optional when `lines` is given.

### Migrating from 0.2.0

- Install `glow-ui-0.3.0.tgz`.
- Headings are smaller and content reveals later. Nothing in your code needs to change.
- Two `RevealText`s joined by a `<br />` with hand-picked delays can become one `RevealText lines={[…]}`.
- To use `glow-ui/fonts.css`, install `@fontsource/inter` and `@fontsource/inter-tight`, import it, and remove the Google Fonts `<link>`.

## 0.2.0

### Added

- `Button` takes `href` and then renders an `<a>` with the same look. Replaces hand-written `<a className="glow-btn glow-btn--outline">`.
- `ListItem` takes `href` (and `linkProps` for `target`, `rel` and so on). The whole row becomes clickable, and it lights up on hover and keyboard focus. The title is the link text.
- `RevealImage` takes `href` (and `linkProps`). The image gets a quiet frame that lights up with `--glow-shadow-sm` on hover and focus. The same style applies to any `RevealImage` placed directly inside an `<a>`.
- The README has the exact Google Fonts `<link>` tag for Inter and Inter Tight.
- `CHANGELOG.md` and `ROADMAP.md`.

### Changed

- `npm run pack` writes `glow-ui-<version>.tgz` instead of `glow-ui.tgz`. Each release has its own file name, so the consumer has to run `npm install` and its lockfile checksum stays correct.
- `.glow-btn` sets `text-decoration: none`.

### Migrating from 0.1.0

- Install the new tarball by its versioned name: `npm install path/to/glow-ui-0.2.0.tgz`.
- Hand-built link buttons, linked list rows and image-link hover styles can be replaced with the `href` props. Don't copy internal keyframes such as `glow-rise`; they aren't part of the API.

## 0.1.0

First version: controls (Select, Menu, Button, Input, Textarea, Checkbox, Switch, RadioGroup, Slider, Tabs, Tooltip, Dialog, Card, Badge), the Swiss grid (Container, Grid, Col, Stack, Inline, Section, GridOverlay), type (Heading, Text, Eyebrow, Numeral), scroll-reveal motion (Reveal, Stagger, RevealText, RevealImage, Rule, Counter, `useReveal`, `useInView`) and content (List, Table).
