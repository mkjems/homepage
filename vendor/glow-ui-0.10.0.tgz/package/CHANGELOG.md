# Changelog

All notable changes to Glow UI. Glow UI is pre-1.0: a minor version (0.x.0) can contain breaking or visible changes, a patch (0.x.y) only fixes. Planned releases are in `ROADMAP.md`.

## 0.10.0

A theme switch that fits a nav, an address bar that follows the theme, and text glow that switches off on paper. From the 0.8.0 feedback.

### Added

- **Checked menu items.** `checked` on a `MenuAction` marks the current choice in a group with a check mark (`role="menuitemradio"`, `aria-checked`). A ghost `Menu` can now offer System / Light / Dark in a header bar. Docs: "Checked items" in `docs/components/menu.md`.
- `MonitorIcon`, for "System".
- **`theme-color`.** `useTheme` keeps every `<meta name="theme-color">` on the page in step with `--glow-bg`, so a phone's address bar is paper in the light theme. It never adds the tag.
- **`--glow-text-shadow` and `--glow-text-shadow-sm`.** Tokens for glowing text, `none` in the light theme like `--glow-shadow*`.
- Docs: a theme switch recipe under the header bar in `docs/layout/grid.md`, and `theme-color` and text glow in `docs/theming.md`.

### Changed

- The library's own text glows (links, list numbers, eyebrow index, selected options, slider value, glow badge) use the new tokens. A few blur radii changed by 2px to fit the two sizes.

### Migrating from 0.9.0

- Install `glow-ui-0.10.0.tgz` from `versions/`. Nothing needs to change.
- If `index.html` has a `<meta name="theme-color">`, remove any code that updates it for the light theme: `useTheme` does that now. Keep the tag, with the dark color for the first paint.
- Replace hand-written glows like `text-shadow: 0 0 10px var(--glow-line)` with `var(--glow-text-shadow-sm)` (or `var(--glow-text-shadow)` for 12px), and drop the `[data-glow-theme='light'] … { text-shadow: none }` overrides you added for them.
- A theme toggle that can't return to System can become a `Menu` with checked items (see the header bar recipe).

## 0.9.0

Icon buttons: icons beside a label, toggles, a few more icons, and icon-only buttons that can't go unnamed.

### Added

- `Button leading` and `trailing`: an icon before or after the label. The padding on that side is trimmed, so `<Button leading={<PlusIcon />}>New project</Button>` looks balanced.
- `Button pressed`: makes the button a toggle. It sets `aria-pressed`, and the button is lit while on (an accent edge, fill and label in the light theme). For `<button>` only, not links.
- Icons: `ArrowRightIcon`, `ExternalLinkIcon`, `CopyIcon`, `MenuIcon`, `MoreIcon`, `SunIcon`, `MoonIcon`.
- `Menu` passes `aria-labelledby` to its trigger.
- The `IconLabel` type, for wrappers that pass `icon` through to `Button`.

### Changed

- **Breaking (types only):** `Button icon` and `Menu icon` require an `aria-label` or `aria-labelledby`. An icon-only button without one is now a TypeScript error instead of an unnamed button.

### Migrating from 0.8.0

- Install `glow-ui-0.9.0.tgz` from `versions/`.
- Run `tsc`. Every error on a `Button icon` or `Menu icon` is a button screen readers couldn't name: add an `aria-label` that says what it does ("Close", "More actions").
- A wrapper that passes a boolean through (`<Button icon={isIcon}>`) doesn't type-check against the new union. Type the wrapper's props with `IconLabel`, or pass `{...({ icon, 'aria-label': label } as IconLabel)}`.
- Optional: replace `<Button><PlusIcon /> New</Button>` with `<Button leading={<PlusIcon />}>New</Button>` for the trimmed padding, and `variant={on ? 'glow' : 'quiet'} aria-pressed={on}` toggles with `pressed={on}`.

## 0.8.0

A light theme, with the same geometry as the dark one. Nothing changes until you opt in.

### Added

- **Light theme.** `data-glow-theme="light"` on `<html>` (or any element) puts the page on paper: ink text, and the accent color from `--glow-h` in place of glow. What has attention (focused, open, checked, primary) gets an accent edge, fill or label; shadows only separate popovers, tooltips and the dialog from the page. Sizes, spacing, radii and type are the same as in the dark theme, so switching moves nothing. Contrast passes WCAG AA in every hue.
- `--glow-paper` and `--glow-ink` tokens, and `--glow-spot` (the accent) in the light theme.
- `useTheme()`: follows the visitor's system setting (`prefers-color-scheme`) until they choose light or dark, remembers the choice in `localStorage` (key `glow-theme`), and sets `data-glow-theme` on `<html>`. Returns `{ theme, resolved, setTheme }`.
- The theme script, which applies the theme before the first paint so light-mode visitors don't see a flash of the dark theme: a `<script>` to paste into `index.html` (in `docs/theming.md`), or `<ThemeScript />` for server-rendered React. Also exported as the string `themeScript`.

### Migrating from 0.7.0

- Install `glow-ui-0.8.0.tgz` from `versions/`. Nothing in your code needs to change: without the steps below the page stays dark.
- **To offer the light theme:** paste the theme script from `docs/theming.md` into `<head>` in `index.html` (or render `<ThemeScript />` with server rendering), and put a switch somewhere that calls `useTheme().setTheme`. The page then follows the visitor's system setting until they choose.
- **Check your own CSS in the light theme.** Colors you wrote yourself (white text, a hard-coded background, your own glow `box-shadow`) stay as they are on paper. Use the tokens (`--glow-text`, `--glow-text-muted`, `--glow-separator`, …), which switch with the theme.
- **Token overrides on `:root` apply to both themes.** An override of `--glow-bg` on `:root` that loads after `glow-ui/styles.css` also replaces the paper. To change a token for one theme only, set it under `[data-glow-theme='light']` (or `:root:not([data-glow-theme='light'])`).

## 0.7.0

Columns per breakpoint: 4 on phones, 8 on tablets, 12 on desktops. Breaking for layouts.

### Changed

- **Breaking:** `Grid` has 4 columns at base, 8 at md and 12 at lg, not 12 everywhere. A `span` counts the columns at the current breakpoint, so `md: 6` is now three quarters of the row, not half.
- A `span` wider than the grid fills the row, and a `start` past the last column fills the row too, so a Col never adds columns the grid doesn't have. `span={12}` is always full width.
- `GridOverlay columns` is responsive and follows the same defaults, so G shows 4, 8 or 12 lines.

### Added

- `--glow-cols`, `--glow-cols-md`, `--glow-cols-lg` tokens: the default column counts. Set them on `:root` to change every grid. `Grid columns` still overrides them per grid.

### Migrating from 0.6.0

- Install `glow-ui-0.7.0.tgz` from `versions/`.
- **Quick way:** `columns={12}` on a Grid gives it 12 columns everywhere again, so its spans keep their old widths. Use it for any grid you aren't converting yet.
- **Converting a grid:** for each `Col`, write down the span it had at each breakpoint before, including the ones it inherited from below. Then convert each one: lg stays the same, md is ⅔ of the old value, base is ⅓.

  | Old span (of 12) | base (of 4) | md (of 8) | lg (of 12) |
  | --- | --- | --- | --- |
  | 12 | leave out | leave out | leave out |
  | 9 | 3 | 6 | 9 |
  | 6 | 2 | 4 | 6 |
  | 3 | 1 | 2 | 3 |

  For example, `span={{ base: 12, md: 6 }}` (half from md up) becomes `span={{ md: 4, lg: 6 }}`. Without `lg: 6`, the `md: 4` would carry up to lg and be a third.
- **Thirds and other spans that don't divide** (4, 8, 2, 10 of 12) have no exact match at base or md. Keep 12 columns where you need them: `columns={{ base: 4, md: 12 }}` keeps thirds from md up.
- `start` converts the same way: line 7 of 12 (the middle) is line 5 of 8.
- `base: 12` and `span="full"` still work. A Col without `span` is full width, so `base: 12` can just be left out.
- Check each page with G (the grid overlay) at 390, 800 and 1280px.

## 0.6.0

Popovers that escape clipped containers.

### Changed

- `Select`, `Menu` and `Tooltip` open in the browser's top layer (the native `popover` attribute), so a parent with `overflow: hidden` no longer clips them. They line up with their trigger, open on the other side when there's more room there, stay inside the viewport and follow the trigger when the page scrolls. Browsers without `popover` keep the old CSS positioning.

### Migrating from 0.5.2

- Install `glow-ui-0.6.0.tgz` from `versions/`. Nothing in your code needs to change.
- Any workaround that kept a Select, Menu or Tooltip out of an `overflow: hidden` container is no longer needed.

## 0.5.2

Roadmap change only. The library is unchanged.

### Changed

- Reveal without JavaScript is no longer planned for 0.6.0. Reveal content still starts hidden, so a server-rendered page shows it only after hydration.

### Migrating from 0.5.1

- Install `glow-ui-0.5.2.tgz` from `versions/`. Nothing in your code needs to change.

## 0.5.1

Documentation fixes from the 0.5.0 feedback.

### Fixed

- `docs/type/links.md` says plainly that a `glow-link` takes its look from its parent element: inside a `<p>` or `Text` it gets the in-text look (text color and hairline underline), even in a footer. Anywhere else it is muted with no underline.
- `docs/type/links.md` and the header bar recipe in `docs/layout/grid.md` show how to size nav links: set `font-size: var(--glow-fs-text-sm)` on the nav, and the links inherit it.
- `Section padding`: the docs and props table say that a string such as `'clamp(32px, 4vw, 48px)'` is used as-is, with a fluid example in `docs/layout/section.md`.
- The 0.4.1 migration note now says to update any upgrade scripts or docs that copy the tarball from the old path.

### Migrating from 0.5.0

- Install `glow-ui-0.5.1.tgz` from `versions/`. Nothing in your code needs to change.
- Nav links set to 14px with your own CSS can use the nav's `style={{ fontSize: 'var(--glow-fs-text-sm)' }}` instead.
- Hand-written fluid `padding-block` around sections can become `Section padding={{ top: 'clamp(…)', bottom: 'clamp(…)' }}`.

## 0.5.0

Quiet text links, and finer control over section spacing.

### Added

- `glow-link`: a class for text links in navs, footers and running text. It is muted with no underline at rest, and glows with `--glow-core` and a `--glow-line` halo on hover and keyboard focus, where it also gets a thin outline. Works on `<button>` too, for text-style actions. A tone class on the same element changes the resting color. Inside a `<p>` or `Text`, it keeps the text color and gets a hairline underline. See `docs/type/links.md`.
- `Section padding={{ top, bottom }}` sets each side separately. A side you leave out keeps the default. A single value still sets both.
- `--glow-section-pad` token: the default section padding, `clamp(64px, 10vw, 144px)`.
- `--glow-anchor-offset` token (`32px`): a `#link` to a `Section` stops this far below the top edge, not flush against it.

### Changed

- `Section` has `scroll-margin-top: var(--glow-anchor-offset)`, so links to its `id` no longer land flush against the top of the window.
- `docs/layout/section.md`: one page-wide `Container` with plain `Section`s inside also works.

### Migrating from 0.4.1

- Install `glow-ui-0.5.0.tgz` from `versions/`. Nothing in your code needs to change.
- Hand-written styles for quiet nav and footer links can become `className="glow-link"`.
- Hand-written `padding-block` and `scroll-margin-top` around sections can become `Section` with `padding={{ top, bottom }}`.

## 0.4.1

Release tarballs live in a `versions/` folder.

### Changed

- `npm run pack` writes the tarball to `versions/glow-ui-<version>.tgz`, and every release is kept there. The README's install and upgrade steps use the new path.

### Migrating from 0.4.0

- Install `glow-ui-0.4.1.tgz` from `versions/`. Nothing in your code needs to change.
- Update any upgrade scripts or docs that copy the tarball from the old path (`glow-ui/glow-ui-<version>.tgz`) to use `glow-ui/versions/glow-ui-<version>.tgz`.

## 0.4.0

Headings in two tones, readable secondary text, and a way to tell which version is installed.

### Added

- `RevealText parts`: a heading built from segments that continue one stagger, each with its own tone, without starting a new row: `parts={['One small server.', { text: 'Shipped on every push.', tone: 'muted' }]}`. A part is a string or `{ text, tone?, break? }`. `break: true` starts a new row. Works with every effect, including `decode`. The element keeps a single `aria-label`.
- Exported type `RevealTextPart`.
- `version`: `import { version } from 'glow-ui'` gives the installed version.
- The shipped `styles.css` starts with a `/* glow-ui 0.4.0 */` comment.
- README: steps for upgrading a tarball kept in the repository, in an order that never leaves its folder empty.
- README: a Scope section. Glow UI is general purpose, and patterns specific to one site are left to that site.
- `docs/layout/grid.md`: a header bar recipe, a wordmark and nav that share one row at 390px.

### Changed

- Secondary text is brighter, so it meets WCAG AA (4.5:1). `--glow-text-faint` was about 2.7:1 and is now 6.7:1 on black and at least 4.7:1 on quiet and glass surfaces in every hue. The one exception is the top edge of a success or warning glass surface, where it is 3.7:1. `--glow-text-muted` was 4.1–6.3:1 and is now 9.8:1 on black and at least 5.2:1 everywhere. This affects `tone="muted"` and `tone="faint"`, help text, placeholders, checkbox descriptions, eyebrows and other secondary text.
- Hairlines are visible: `--glow-separator` goes from `/ 0.1` to `/ 0.3` alpha (about 1.1:1 to 1.8:1 on black). This affects `Rule tone="hairline"`, list and table row lines, `Divider` and menu separators.
- `RevealText` with `effect="decode"` now renders the same wrapper and `data-*` attributes as the other effects.

### Fixed

- `RevealText effect="rise"` no longer cuts the glow off `tone="glow"` text into a box around each word. Words are clipped only while they rise.

### Migrating from 0.3.1

- Install `glow-ui-0.4.0.tgz`, following the new upgrade steps in the README if the tarball lives in your repository.
- Muted text, faint text and hairlines are brighter. Nothing in your code needs to change.
- A heading built from several `RevealText`s or spans to get a second tone can become one `RevealText parts={[…]}`.

## 0.3.1

Documentation for every component, shipped in the package.

### Added

- `docs/`: usage guides for every component, shipped in the package at `node_modules/glow-ui/docs/`. Start with `docs/principles.md`; `docs/README.md` is the index, and `docs/theming.md` lists every token.
- Each page ends with a props table (type, default, description) generated from the TypeScript source, plus the definitions of the Glow UI types it uses.
- Doc comments, and `@default` where the default lives in CSS, for every public prop, so they also show up on hover in your editor.
- `CHANGELOG.md` now ships in the package.

### Changed

- `InlineProps` is an interface instead of a type alias. It accepts the same props.
- `--glow-font-display` moved next to `--glow-font` at the top of `styles.css`. Same value.

### Migrating from 0.3.0

- Install `glow-ui-0.3.1.tgz`. Nothing in your code needs to change.
- Point your AI assistant at `node_modules/glow-ui/docs/README.md`.

## 0.3.0

Calmer type and motion.

### Added

- Type scale tokens at the top of `styles.css`: `--glow-fs-display`, `--glow-fs-xl`, `--glow-fs-l`, `--glow-fs-m`, `--glow-fs-s`, `--glow-fs-numeral`, and `--glow-fs-text-lg` / `--glow-fs-text` / `--glow-fs-text-sm` / `--glow-fs-text-xs`. Override them to tune the scale.
- `--glow-reveal-offset` token (default `25%`) sets how far up the viewport content must scroll before it reveals. `useInView` reads it once per page.
- `offset` for a single element: in `reveal={{ effect, offset }}`, on `Reveal`, `RevealText`, `RevealImage`, `Rule` and `Counter`, and in `useInView` options. A number is a percentage of the viewport height, a string any length (`'120px'`).
- `RevealText lines={["Games for", "the browser."]}` puts each line on its own row and staggers through them in one sequence. Works with every effect, including `decode`.
- `glow-ui/fonts.css`: optional self-hosted Inter and Inter Tight via `@fontsource/inter` and `@fontsource/inter-tight`, which are optional peer dependencies.
- Exported types `RevealOffset` and `InViewOptions`.

### Changed

- Smaller large headings: display `clamp(48px, 9vw, 136px)` (was `clamp(56px, 11.5vw, 184px)`), xl `clamp(36px, 5.2vw, 76px)` (was `clamp(40px, 6.4vw, 96px)`), l `clamp(28px, 3.2vw, 46px)` (was `clamp(30px, 3.8vw, 56px)`). The m, s, numeral and text sizes are unchanged.
- Content reveals later: when its top is 25% above the bottom of the viewport (was 10%).
- Content near the end of the page that can never scroll that high now reveals when the page is scrolled to the bottom.
- `RevealText` `children` is optional when `lines` is given.

### Migrating from 0.2.0

- Install `glow-ui-0.3.0.tgz`.
- Headings are smaller and content reveals later. Nothing in your code needs to change.
- Two `RevealText`s joined by a `<br />` with hand-picked delays can become one `RevealText lines={[…]}`.
- To use `glow-ui/fonts.css`, install `@fontsource/inter` and `@fontsource/inter-tight`, import it, and remove the Google Fonts `<link>`.

## 0.2.0

### Added

- `Button` takes `href` and then renders an `<a>` with the same look. Replaces hand-written `<a className="glow-btn glow-btn--outline">`.
- `ListItem` takes `href` (and `linkProps` for `target`, `rel` and so on). The whole row becomes clickable, and it lights up on hover and keyboard focus. The title is the link text.
- `RevealImage` takes `href` (and `linkProps`). The image gets a quiet frame that lights up with `--glow-shadow-sm` on hover and focus. The same style applies to any `RevealImage` placed directly inside an `<a>`.
- The README has the exact Google Fonts `<link>` tag for Inter and Inter Tight.
- `CHANGELOG.md` and `ROADMAP.md`.

### Changed

- `npm run pack` writes `glow-ui-<version>.tgz` instead of `glow-ui.tgz`. Each release has its own file name, so the consumer has to run `npm install` and its lockfile checksum stays correct.
- `.glow-btn` sets `text-decoration: none`.

### Migrating from 0.1.0

- Install the new tarball by its versioned name: `npm install path/to/glow-ui-0.2.0.tgz`.
- Hand-built link buttons, linked list rows and image-link hover styles can be replaced with the `href` props. Don't copy internal keyframes such as `glow-rise`; they aren't part of the API.

## 0.1.0

First version: controls (Select, Menu, Button, Input, Textarea, Checkbox, Switch, RadioGroup, Slider, Tabs, Tooltip, Dialog, Card, Badge), the Swiss grid (Container, Grid, Col, Stack, Inline, Section, GridOverlay), type (Heading, Text, Eyebrow, Numeral), scroll-reveal motion (Reveal, Stagger, RevealText, RevealImage, Rule, Counter, `useReveal`, `useInView`) and content (List, Table).
