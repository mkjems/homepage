# Section

A page section with consistent vertical spacing.

```tsx
<Section id="work">
  <Container>
    <Grid>…</Grid>
  </Container>
</Section>

<Section padding="none">…</Section>   {/* full-bleed band, you handle the spacing */}

<Section padding={{ top: 4 }}>         {/* starts with a Rule: tighter top, default bottom */}
  <Rule />
  …
</Section>

<Section padding={{ top: 'clamp(32px, 4vw, 48px)', bottom: 'clamp(96px, 14vw, 200px)' }}>   {/* fluid */}
  <Rule />
  …
</Section>
```

## When to use

- Wrap each top-level part of a page (hero, work, about, contact) in a `Section` so the space between them is the same everywhere: a fluid 64–144px, top and bottom.
- Put the `Container` inside the `Section`, so a section background can run edge to edge while the content keeps the page margins. One `Container` around the whole page, with plain `Section`s inside it, works too when no section needs a full-width background.
- Override with `padding` only for a deliberate change in rhythm, like a tighter hero (`padding={6}` is 48px). `padding={{ top, bottom }}` sets one side and leaves the other at the default. A number is a multiple of 8px, and a string such as `'clamp(32px, 4vw, 48px)'` is used as-is, for fluid spacing. Change the default everywhere with the `--glow-section-pad` token.
- A link to `#id` scrolls the section in with `--glow-anchor-offset` (32px) of space above it. Under a sticky header, set the token to the header's height plus some air.
- Renders a `<section>`. Start it with a heading. To make it a landmark screen reader users can jump to, also give it `aria-labelledby` pointing at that heading (or an `aria-label`).

## Props

<!-- props:Section -->
| Prop | Type | Default | Description |
| --- | --- | --- | --- |
| `padding` | `SectionPad \| { top?: SectionPad; bottom?: SectionPad }` | `--glow-section-pad` (clamp(64px, 10vw, 144px)) | Vertical padding for top and bottom, or `{ top, bottom }` to set them separately. A number is a multiple of the 8px unit, a string (such as a `clamp()`) is used as-is, and `'none'` is 0. A side you leave out keeps the default. |
| `reveal` | `RevealProp` |  | Animate in when scrolled into view. |
| `stagger` | `StaggerProp` |  | Animate direct children one after another (true = 80ms apart, or a number of ms). |
| `as` | `ElementType` | `'section'` | The element to render, e.g. `'section'`, `'ul'`, `'ol'`. |

`className` and `style` are passed to the root element. Also accepts the standard HTML attributes of the rendered element.

Types used above:

```ts
type SectionPad = Space | 'none';

/** Spacing: a number is a multiple of the 8px unit; a string is used as-is. */
type Space = number | string;
```

`RevealProp`, `StaggerProp`: see [motion/reveal.md](../motion/reveal.md).
<!-- /props -->
