# Stack, Inline

Flexbox for arranging things inside a grid column: `Stack` is a column, `Inline` a wrapping row.

```tsx
<Stack gap={3}>
  <Eyebrow index="02">Contact</Eyebrow>
  <Heading level={2}>Say hello.</Heading>
  <Inline gap={1.5}>
    <Button variant="glow" href="mailto:hi@example.com">Email</Button>
    <Button variant="outline" href="https://github.com/example">GitHub</Button>
  </Inline>
</Stack>
```

## When to use

- `Stack` for vertical rhythm between blocks: eyebrow, heading, text, buttons.
- `Inline` for things side by side that may wrap on a phone: buttons, badges, tags. It centers items vertically by default.
- `Inline wrap={false}` only when the content is guaranteed to fit, or it will overflow at 390px.
- For page-level columns, use `Grid` and `Col`, not nested Stacks.
- Gaps are multiples of 8px: `gap={1}` 8px, `gap={2}` 16px (default), `gap={3}` 24px. Use the larger steps between groups, the smaller ones inside a group.
- `as="ul"` or `as="nav"` for semantic markup, with `stagger` to animate the children in turn.

## Props

### Stack

<!-- props:Stack -->
| Prop | Type | Default | Description |
| --- | --- | --- | --- |
| `gap` | `Space` | `2` | Space between children. |
| `align` | `CSSProperties['alignItems']` |  | CSS `align-items`: cross-axis alignment of the children. |
| `justify` | `CSSProperties['justifyContent']` |  | CSS `justify-content`: main-axis distribution of the children. |
| `reveal` | `RevealProp` |  | Animate in when scrolled into view. |
| `stagger` | `StaggerProp` |  | Animate direct children one after another (true = 80ms apart, or a number of ms). |
| `as` | `ElementType` | `'div'` | The element to render, e.g. `'section'`, `'ul'`, `'ol'`. |

`className` and `style` are passed to the root element. Also accepts the standard HTML attributes of the rendered element.

Types used above:

```ts
/** Spacing: a number is a multiple of the 8px unit; a string is used as-is. */
type Space = number | string;
```

`RevealProp`, `StaggerProp`: see [motion/reveal.md](../motion/reveal.md).
<!-- /props -->

### Inline

<!-- props:Inline -->
| Prop | Type | Default | Description |
| --- | --- | --- | --- |
| `wrap` | `boolean` | `true` | Let children wrap onto new lines. `false` keeps them on one line. |
| `gap` | `Space` | `2` | Space between children. |
| `align` | `CSSProperties['alignItems']` |  | CSS `align-items`: cross-axis alignment of the children. |
| `justify` | `CSSProperties['justifyContent']` |  | CSS `justify-content`: main-axis distribution of the children. |
| `reveal` | `RevealProp` |  | Animate in when scrolled into view. |
| `stagger` | `StaggerProp` |  | Animate direct children one after another (true = 80ms apart, or a number of ms). |
| `as` | `ElementType` | `'div'` | The element to render, e.g. `'section'`, `'ul'`, `'ol'`. |

`className` and `style` are passed to the root element. Also accepts the standard HTML attributes of the rendered element.

`RevealProp`, `StaggerProp`: see [motion/reveal.md](../motion/reveal.md).
<!-- /props -->
