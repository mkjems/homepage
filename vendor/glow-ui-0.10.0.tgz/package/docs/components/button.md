# Button

An action, or a link that looks like one.

```tsx
<Button variant="glow">Publish</Button>
<Button variant="outline" href="/games" trailing={<ArrowRightIcon />}>Play</Button>
<Button variant="ghost" size="sm" onClick={close}>Cancel</Button>
<Button leading={<PlusIcon />}>New project</Button>
<Button icon aria-label="Add"><PlusIcon /></Button>
<Button icon variant="ghost" aria-label="Sidebar" pressed={open} onClick={toggle}><MenuIcon /></Button>
```

## When to use

- `glow`: the one primary action in a view. Only one per screen or dialog.
- `quiet` (default): ordinary actions.
- `outline`: secondary calls to action, often links such as "Play →" or "Read more".
- `ghost`: low-emphasis actions next to a primary one, like Cancel in a dialog, or in toolbars.
- Sizes: `sm` in dense UI and toolbars, `md` by default, `lg` for a hero call to action.
- If it navigates, pass `href`. It renders an `<a>` with the same look and accepts `target`, `rel` and other anchor attributes.
- Don't write `<a className="glow-btn glow-btn--outline">`. Use `<Button variant="outline" href="…">`.

## Icons

- **Icon and text:** pass the icon as `leading` or `trailing`, not as a child. The padding on that side is trimmed, so the icon and text look balanced. `trailing` suits arrows on links and the external-link icon. Use only one of the two.
- **Icon only:** `icon` makes the button square (32, 40 or 48px), with the icon as its only child. It has no visible text, so TypeScript requires an `aria-label` or `aria-labelledby`. A `Tooltip` can show the same name on hover.
- Icons are sized for you: 18px, or 15px at `sm`. Any SVG works, the bundled [icons](icons.md) or your own.

## Toggles

`pressed` turns a button into a toggle: on (`true`) it's lit like a selected tab, off (`false`) it rests. Use it for a setting the button switches, such as a sidebar, a grid overlay or bold text, and keep the label the same in both states. If the label changes with the state ("Play" / "Pause"), don't use `pressed`: change the label instead.

- Use `quiet`, `ghost` or `outline` for toggles. `glow` is lit already, so it has no visible on state.
- Leave `pressed` out (not `false`) for ordinary buttons: `false` tells screen readers "toggle, off".
- Not on links: `pressed` is for `<button>` only.

## States

| State | `glow` | `outline` | `quiet` / `ghost` |
| --- | --- | --- | --- |
| Resting | small glow | faint neon edge | glass / text only |
| Hover | full glow | small glow | lighter glass |
| Keyboard focus | small glow ring | small glow ring | small glow ring |
| Pressed (`pressed`) | n/a | lit glass, neon edge, small glow | same |
| Disabled | dimmed to 45%, no glow | same | same |

## Accessibility

- Renders a native `<button type="button">`, so pass `type="submit"` explicitly in forms.
- An `icon` button has no visible text, so `aria-label` or `aria-labelledby` is required. TypeScript reports a missing one.
- `pressed` sets `aria-pressed`, so screen readers announce a toggle button and its state.
- With `href` it's a real link, so it opens in a new tab and works with the keyboard and screen readers as one.

## Props

<!-- props:Button -->
| Prop | Type | Default | Description |
| --- | --- | --- | --- |
| `href` | `string` |  | Renders an `<a>` with the same look. Use it whenever the button navigates. |
| `pressed` | `boolean` |  | Makes the button a toggle: sets `aria-pressed`, and the button is lit while `true`. Leave it out for an ordinary button. |
| `variant` | `ButtonVariant` | `'quiet'` | `glow` solid neon, `quiet` frosted glass, `outline` neon edge, `ghost` text only. |
| `size` | `ButtonSize` | `'md'` | `sm` for dense UI and toolbars, `md` for most buttons, `lg` for a hero call to action. |
| `icon` | `boolean` | `false` | Square button for a single icon, with no visible text. Requires `aria-label` or `aria-labelledby`. |
| `leading` | `ReactNode` |  | Icon before the label. The padding on that side is trimmed, so icon and text look centered. |
| `trailing` | `ReactNode` |  | Icon after the label, like an arrow on a link. |

`className` and `style` are passed to the root element. Also accepts the standard HTML attributes of `<button>` or `<a>` (with `href`).

Types used above:

```ts
type ButtonVariant = 'glow' | 'quiet' | 'outline' | 'ghost';

type ButtonSize = 'sm' | 'md' | 'lg';
```
<!-- /props -->
