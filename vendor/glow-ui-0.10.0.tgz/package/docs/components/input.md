# Input, Textarea

Text fields with a label, help text and error state.

```tsx
<Input label="Email" type="email" hint="We never share it." />
<Input label="Search" leading={<SearchIcon />} placeholder="Find a project" />
<Input label="Slug" error="Already taken." defaultValue="orbit" />
<Textarea label="Message" rows={4} />
```

Everything else (`value`, `onChange`, `type`, `required`, `ref`, …) goes to the native `<input>` or `<textarea>`.

## When to use

- Always give a `label`. A placeholder is not a label.
- `hint` for help that's always useful. `error` for what went wrong, written as how to fix it.
- `leading` for an icon or a unit prefix, `trailing` for a suffix or a small button (clear, show password).
- `sweep` adds a streak of light around the border while focused. Use it for the one field that matters, like a hero search.
- `Textarea bare` removes the field chrome, for writing directly inside a glowing `Card`. Label it with `aria-label`.

## States

- **Resting:** quiet frosted field.
- **Focused:** glowing edge.
- **Error:** the field and help text turn red (`glow-danger`).
- **Disabled:** dimmed.

## Accessibility

Handled for you: the label is linked with `htmlFor`, the hint or error with `aria-describedby`, and an error sets `aria-invalid`. An `id` is generated if you don't pass one.

## Props

### Input

<!-- props:Input -->
| Prop | Type | Default | Description |
| --- | --- | --- | --- |
| `leading` | `ReactNode` |  | Icon or text before the input. |
| `trailing` | `ReactNode` |  | Icon, text or button after the input. |
| `label` | `ReactNode` |  | Visible label above the field, linked to it with `htmlFor`. |
| `hint` | `ReactNode` |  | Helper text under the field. |
| `error` | `ReactNode` |  | Error text; also turns the field red. |
| `sweep` | `boolean` |  | A streak of light runs around the border while focused. |

`className` and `style` are passed to the root element. Also accepts the standard HTML attributes of `<input>`.
<!-- /props -->

### Textarea

<!-- props:Textarea -->
| Prop | Type | Default | Description |
| --- | --- | --- | --- |
| `bare` | `boolean` |  | No field chrome at all: for composing inside a glowing Card. |
| `label` | `ReactNode` |  | Visible label above the field, linked to it with `htmlFor`. |
| `hint` | `ReactNode` |  | Helper text under the field. |
| `error` | `ReactNode` |  | Error text; also turns the field red. |
| `sweep` | `boolean` |  | A streak of light runs around the border while focused. |

`className` and `style` are passed to the root element. Also accepts the standard HTML attributes of `<textarea>`.
<!-- /props -->
