# Card, Divider

A frosted glass panel, and a hairline to separate content.

```tsx
<Card>
  <Heading level={3}>Orbit</Heading>
  <Text tone="muted">A tiny gravity game.</Text>
</Card>

<Card glow="full" sweep>Featured</Card>
<Card hue={152} glow="soft">Deployed</Card>

<Divider />
```

`Card` passes everything else to its `<div>`, including `ref`. It has 20px padding; arrange the content inside with `Stack`.

## When to use

- `glow="none"` (default) for ordinary cards. Most cards on a page should be quiet.
- `glow="soft"` for a selected or active card.
- `glow="full"` with the wide halo for the one card you want noticed: a featured project, a pricing plan. One per screen.
- `sweep` adds a light streak that keeps travelling around the border. It's loud, so use it rarely, and never on more than one card at a time.
- `hue` retints the card and everything inside it, e.g. green for success.
- `Divider` between groups of content inside a card or a column. For section dividers that draw themselves in, use `Rule`.

## States

Cards aren't interactive by themselves. If the whole card is clickable, put a link inside and give it a visible focus style.

## Accessibility

`Card` is a plain `<div>`: add a heading inside so screen reader users can find it. `Divider` is an `<hr>`, announced as a separator.

## Props

### Card

<!-- props:Card -->
| Prop | Type | Default | Description |
| --- | --- | --- | --- |
| `glow` | `GlowLevel` | `'none'` | How strongly the edge glows. `full` includes the wide halo that lights the background. |
| `sweep` | `boolean` | `false` | A streak of light that keeps travelling around the border. |
| `hue` | `number` |  | Retint this card and everything inside it (0–360). |

`className` and `style` are passed to the root element. Also accepts the standard HTML attributes of the rendered element.

Types used above:

```ts
type GlowLevel = 'none' | 'soft' | 'full';
```
<!-- /props -->

### Divider

<!-- props:Divider -->
No props of its own.

`className` and `style` are passed to the root element. Also accepts the standard HTML attributes of the rendered element.
<!-- /props -->
