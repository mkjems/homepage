# Slider

Pick a number in a range by dragging. A native range input with a neon fill.

```tsx
<Slider label="Volume" defaultValue={60} showValue />
<Slider
  label="Opacity"
  min={0}
  max={1}
  step={0.05}
  value={opacity}
  onChange={setOpacity}
  showValue={(v) => `${Math.round(v * 100)}%`}
/>
```

## When to use

- An approximate value where the user wants to see the effect while dragging: volume, opacity, zoom.
- For an exact value (a price, a year), use `Input type="number"`.
- `showValue` when the number matters; pass a function to add units or format it.
- `onChange` gets a number, not an event.

## States

- **Resting:** the filled part of the track glows softly.
- **Keyboard focus:** the thumb glows.
- **Disabled:** dimmed.

## Accessibility

Native `<input type="range">`: arrow keys, Page Up/Down, Home and End work, and screen readers announce the value. Give it a `label`, or an `aria-label` when there's none. For a formatted value, also pass `aria-valuetext`.

## Props

<!-- props:Slider -->
| Prop | Type | Default | Description |
| --- | --- | --- | --- |
| `value` | `number` |  | The current value, for a controlled slider. Use with `onChange`. |
| `defaultValue` | `number` | `min` | The initial value, for an uncontrolled slider. |
| `onChange` | `(value: number) => void` |  | Called with the new value as a number while the user drags. |
| `min` | `number` | `0` | Lowest value, at the left end. |
| `max` | `number` | `100` | Highest value, at the right end. |
| `step` | `number` | `1` | Size of each increment, also used by the arrow keys. |
| `label` | `ReactNode` |  | Visible label above the slider. Without it, pass `aria-label`. |
| `showValue` | `boolean \| ((value: number) => ReactNode)` | `false` | Show the current value next to the label; pass a function to format it. |

`className` and `style` are passed to the root element. Also accepts the standard HTML attributes of `<input>`.
<!-- /props -->
