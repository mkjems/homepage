# Badge

A small label for a status or a category.

```tsx
<Badge>Draft</Badge>
<Badge variant="glow" dot>Live</Badge>
<Badge tone="success" dot>Deployed</Badge>
<Badge tone="danger">Failed</Badge>
```

## When to use

- One or two words of status or category next to a title or in a table row.
- `variant="glow"` for a status that needs attention right now, like "Live". Everything else stays `quiet`.
- `dot` for a running state (live, online, building).
- `tone` sets the hue for meaning: `success`, `warning`, `danger`. The default `accent` follows the theme.
- Not clickable. For a filter chip or a toggle, use a `Button size="sm"`.

## Accessibility

A plain `<span>`. Color alone doesn't carry meaning to everyone, so the text has to say the status ("Failed", not just a red badge).

## Props

<!-- props:Badge -->
| Prop | Type | Default | Description |
| --- | --- | --- | --- |
| `variant` | `'glow' \| 'quiet'` | `'quiet'` | `glow` lit neon, `quiet` frosted. |
| `tone` | `'accent' \| 'success' \| 'warning' \| 'danger'` | `'accent'` | Hue preset; overrides the theme color for this badge. |
| `dot` | `boolean` |  | Small glowing status dot before the text. |

`className` and `style` are passed to the root element. Also accepts the standard HTML attributes of the rendered element.
<!-- /props -->
