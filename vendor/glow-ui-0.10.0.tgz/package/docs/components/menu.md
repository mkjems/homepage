# Menu

A button that opens a list of actions.

```tsx
<Menu
  trigger={<SparkIcon />}
  icon
  aria-label="Project actions"
  align="end"
  items={[
    { label: 'Duplicate', hint: '⌘D', onSelect: duplicate },
    { label: 'Rename', onSelect: rename },
    { separator: true },
    { label: 'Delete', danger: true, onSelect: remove },
  ]}
/>
```

## When to use

- A handful of actions that would clutter the screen as separate buttons: row actions, "more" buttons, toolbars.
- For picking a value, use `Select`. For navigation, use links.
- Put destructive actions last, after a separator, with `danger`.
- An icon-only trigger (`icon`) needs an `aria-label` or `aria-labelledby`; TypeScript reports a missing one. `MoreIcon` is the usual trigger for a "more actions" menu.
- `align="end"` when the trigger sits at the right edge, so the menu doesn't run off the page.

## Checked items

A short Menu can also offer a choice of options, such as a theme, a sort order or a view mode, when a `Select` would be too heavy (in a header bar of text links, for example). Set `checked` on every item of the group: `true` on the current one, `false` on the others. The current item gets a check mark, like a Select option.

```tsx
const { theme, setTheme } = useTheme();

<Menu
  variant="ghost"
  trigger="Theme"
  align="end"
  items={[
    { label: 'System', icon: <MonitorIcon />, checked: theme === 'system', onSelect: () => setTheme('system') },
    { label: 'Light', icon: <SunIcon />, checked: theme === 'light', onSelect: () => setTheme('light') },
    { label: 'Dark', icon: <MoonIcon />, checked: theme === 'dark', onSelect: () => setTheme('dark') },
  ]}
/>
```

- Choosing an item still closes the menu and calls `onSelect`. The Menu doesn't keep the choice: update `checked` from your state.
- Keep ordinary actions out of a checked group, or put a separator between them.
- For a value inside a form, or a longer list, use `Select`.

## States

- **Closed:** the trigger looks like a `Button` of the given `variant`.
- **Open:** the trigger dims (pressed) and the menu glows. It grows in from the trigger.
- **Active item:** highlighted under the pointer or keyboard. Disabled items are dimmed and skipped.

## Accessibility

Handled for you: `menu` / `menuitem` roles (`menuitemradio` with `aria-checked` for checked items), `aria-haspopup`, `aria-expanded`, `aria-activedescendant`. Keys: ↓ or ↑ on the trigger opens it at the first or last item, ↑ ↓ Home End move, Enter or Space runs the item, Esc closes and returns focus to the trigger, Tab closes.

## Positioning

Like `Select`, the menu opens in the top layer, so a parent with `overflow: hidden` doesn't clip it. It lines up with the trigger (`align`), opens above it when there's more room there, and stays inside the viewport. Browsers without `popover` (before Safari 17, Chrome 114, Firefox 125) fall back to CSS positioning, where a parent with `overflow: hidden` still clips it.

## Props

<!-- props:Menu -->
| Prop | Type | Default | Description |
| --- | --- | --- | --- |
| `items` | `MenuItem[]` | required | Actions; insert `{ separator: true }` to draw a divider. |
| `trigger` | `ReactNode` | required | Content of the trigger button. |
| `aria-label` | `string` |  | Names the trigger. Required (or `aria-labelledby`) when it's icon-only. |
| `aria-labelledby` | `string` |  | Names the trigger by another element's id. |
| `variant` | `ButtonVariant` | `'quiet'` | Look of the trigger button. See Button. |
| `size` | `ButtonSize` | `'md'` | Size of the trigger button. |
| `icon` | `boolean` | `false` | Square icon-only trigger. Requires `aria-label` or `aria-labelledby`. |
| `align` | `'start' \| 'end'` | `'start'` | Which edge of the trigger the menu lines up with. Use `end` at the right edge of the page. |

`className` is passed to the root element.

Types used above:

```ts
type MenuItem = MenuAction | Separator;

type ButtonVariant = 'glow' | 'quiet' | 'outline' | 'ghost';

type ButtonSize = 'sm' | 'md' | 'lg';

interface MenuAction {
  label: ReactNode;
  /** Secondary text on the right, e.g. a shortcut like "⌘D". */
  hint?: ReactNode;
  /** Icon before the label. */
  icon?: ReactNode;
  /** Called when the item is chosen. The menu has already closed. */
  onSelect?: () => void;
  disabled?: boolean;
  /** Tints the item red, for destructive actions like Delete. */
  danger?: boolean;
  /**
   * Marks the current choice in a group of options (System / Light / Dark, a sort order) with a
   * check mark. Set it on every item of the group, `true` on one and `false` on the others: they
   * become radio items. Leave it out on ordinary actions.
   */
  checked?: boolean;
}

type Separator = { separator: true };
```
<!-- /props -->
