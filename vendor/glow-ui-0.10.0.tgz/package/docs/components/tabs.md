# Tabs

Switch between views in the same place.

```tsx
<Tabs
  aria-label="Project views"
  items={[
    { value: 'overview', label: 'Overview', content: <Overview /> },
    { value: 'activity', label: 'Activity', content: <Activity /> },
    { value: 'settings', label: 'Settings', content: <Settings />, disabled: !isOwner },
  ]}
/>
```

Without `content`, Tabs is a segmented control: track the value with `onChange` and render the view yourself.

```tsx
<Tabs aria-label="Device" value={device} onChange={setDevice} items={[{ value: 'desktop', label: 'Desktop' }, { value: 'phone', label: 'Phone' }]} />
```

## When to use

- 2–6 views of the same thing that the user switches between. Labels of one or two words.
- For navigating to another page, use links. For a choice inside a form, use `RadioGroup`.
- Don't hide content the user needs to compare side by side behind tabs.

## States

- **Resting tab:** muted text.
- **Hover:** lighter text.
- **Selected:** lit with the small glow.
- **Disabled:** dimmed and skipped by the arrow keys.

## Accessibility

Handled for you: `tablist` / `tab` / `tabpanel` roles, `aria-selected`, `aria-controls`, and one tab stop for the whole list. Keys: ← → move and select (automatic activation), Home and End jump to the first and last tab. Give the list an `aria-label`.

## Props

<!-- props:Tabs -->
| Prop | Type | Default | Description |
| --- | --- | --- | --- |
| `items` | `TabItem<string>[]` | required | The tabs, in order. |
| `value` | `string` |  | The selected tab, for controlled tabs. Use with `onChange`. |
| `defaultValue` | `string` | the first enabled tab | The initially selected tab, for uncontrolled tabs. |
| `onChange` | `(value: string) => void` |  | Called with the tab's value when the user selects it. |
| `aria-label` | `string` |  | Accessible name for the tab list, e.g. "Project views". |

`className` is passed to the root element.

Types used above:

```ts
interface TabItem<V extends string = string> {
  value: V;
  /** Text on the tab. */
  label: ReactNode;
  /** Panel shown under the tabs while this tab is selected. Leave it out to use Tabs as a segmented control and render the content yourself. */
  content?: ReactNode;
  disabled?: boolean;
}
```
<!-- /props -->
