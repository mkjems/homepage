# Dialog

A modal window on top of the page, built on the native `<dialog>`.

```tsx
const [open, setOpen] = useState(false);

<Button onClick={() => setOpen(true)}>Publish…</Button>
<Dialog
  open={open}
  onClose={() => setOpen(false)}
  title="Publish site?"
  description="Bloom will go live at bloom.example.com."
  footer={
    <>
      <Button variant="ghost" onClick={() => setOpen(false)}>Cancel</Button>
      <Button variant="glow" onClick={publish}>Publish</Button>
    </>
  }
>
  <Switch label="Notify subscribers" defaultChecked />
</Dialog>
```

## When to use

- A decision or a short task that must be finished or cancelled before going on: confirming, publishing, a small form.
- Not for information the user might want to keep reading while using the page.
- Always give a `title`. Keep the `footer` to one primary (`glow`) button and one `ghost` Cancel, with the primary last.
- `onClose` must set `open` to `false`. The dialog doesn't close itself.

## States

- **Opening:** the panel grows in, lit with the full glow; the page behind is dimmed.
- **Closing:** Esc, a click on the backdrop, or your own buttons.

## Accessibility

The native `<dialog>` traps focus, closes on Esc, sits in the top layer above everything, and makes the rest of the page inert. The `title` and `description` become its accessible name and description. When it closes, focus returns to the element that opened it.

## Props

<!-- props:Dialog -->
| Prop | Type | Default | Description |
| --- | --- | --- | --- |
| `open` | `boolean` | required | Whether the dialog is shown. The dialog is always controlled. |
| `onClose` | `() => void` | required | Called on Esc, a backdrop click or a `<form method="dialog">` submit. Set `open` to false here. |
| `title` | `ReactNode` |  | Heading of the dialog, also its accessible name. |
| `description` | `ReactNode` |  | Short text under the title, also its accessible description. |
| `children` | `ReactNode` |  | Body content between the description and the footer. |
| `footer` | `ReactNode` |  | Buttons along the bottom edge. |

`className` is passed to the root element.
<!-- /props -->
