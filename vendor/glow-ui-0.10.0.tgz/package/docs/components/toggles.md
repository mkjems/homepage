# Checkbox, Switch, RadioGroup

On/off and one-of-several choices, built on native inputs.

```tsx
<Checkbox label="Accept the terms" description="You can unsubscribe at any time." />
<Switch label="Notify subscribers" defaultChecked />
<RadioGroup
  label="Plan"
  defaultValue="pro"
  options={[
    { value: 'free', label: 'Free' },
    { value: 'pro', label: 'Pro', description: 'Custom domain and analytics' },
  ]}
  onChange={setPlan}
/>
```

`Checkbox` and `Switch` pass everything else (`checked`, `defaultChecked`, `onChange`, `name`, `ref`) to the native `<input type="checkbox">`.

## When to use

- `Checkbox`: an option that is applied later, typically when a form is submitted. Several checkboxes can be on at once.
- `Switch`: a setting that takes effect immediately, like a light switch.
- `RadioGroup`: exactly one of 2–5 options that should all stay visible. For more, use `Select`.
- Use `orientation="horizontal"` only for short labels.
- Write labels as the "on" state: "Notify subscribers", not "Don't notify".

## States

- **Off / resting:** quiet glass box or track.
- **Checked / on:** lit with the theme glow.
- **Keyboard focus:** small glow ring.
- **Disabled:** dimmed.

## Accessibility

Native inputs underneath, so forms, labels, Space to toggle and screen readers all work. `Switch` adds `role="switch"`. `RadioGroup` is a `<fieldset>` with the `label` as its `<legend>`, and the arrow keys move between options.

## Props

### Checkbox

<!-- props:Checkbox -->
| Prop | Type | Default | Description |
| --- | --- | --- | --- |
| `label` | `ReactNode` |  | Text next to the box. Clicking it toggles the checkbox. |
| `description` | `ReactNode` |  | Smaller muted text under the label. |

`className` and `style` are passed to the root element. Also accepts the standard HTML attributes of `<input>`.
<!-- /props -->

### Switch

<!-- props:Switch -->
| Prop | Type | Default | Description |
| --- | --- | --- | --- |
| `label` | `ReactNode` |  | Text next to the switch. Clicking it toggles the switch. |
| `description` | `ReactNode` |  | Smaller muted text under the label. |

`className` and `style` are passed to the root element. Also accepts the standard HTML attributes of `<input>`.
<!-- /props -->

### RadioGroup

<!-- props:RadioGroup -->
| Prop | Type | Default | Description |
| --- | --- | --- | --- |
| `options` | `RadioOption<string>[]` | required | One radio per option, in order. |
| `value` | `string \| null` |  | The selected value, for a controlled group. Use with `onChange`. |
| `defaultValue` | `string \| null` |  | The initially selected value, for an uncontrolled group. |
| `onChange` | `(value: string) => void` |  | Called with the new value when the user picks an option. |
| `label` | `ReactNode` |  | Group label, rendered as the fieldset's `<legend>`. |
| `name` | `string` | a generated id | `name` of the radio inputs, for form submission. |
| `orientation` | `'vertical' \| 'horizontal'` | `'vertical'` | `horizontal` puts the options in a wrapping row. |
| `disabled` | `boolean` |  | Disables every option. |

`className` is passed to the root element.

Types used above:

```ts
interface RadioOption<V extends string = string> {
  value: V;
  label: ReactNode;
  /** Smaller muted text under the label. */
  description?: ReactNode;
  disabled?: boolean;
}
```
<!-- /props -->
