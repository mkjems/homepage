# Icons

The small set of line icons the components use, exported for your own buttons.

```tsx
import { PlusIcon, SearchIcon } from 'glow-ui';

<Button icon aria-label="Add"><PlusIcon /></Button>
<Button leading={<CopyIcon />}>Copy</Button>
<Input label="Search" leading={<SearchIcon />} />
```

Available:

- **Actions:** `PlusIcon`, `CloseIcon`, `CopyIcon`, `SearchIcon`, `CheckIcon`, `SparkIcon`, `PointerIcon`
- **Direction and links:** `ArrowRightIcon`, `ArrowUpIcon`, `ChevronDownIcon`, `ExternalLinkIcon`
- **Navigation:** `MenuIcon` (a sidebar or nav), `MoreIcon` (a "more actions" Menu)
- **Theme:** `SunIcon`, `MoonIcon`, `MonitorIcon` (System), for a theme switch (see [theming](../theming.md))

## When to use

- Inside `Button` (as a child of `icon`, or as `leading` / `trailing`), `Menu` items and Input `leading` / `trailing`, which size them for you. Elsewhere, pass `width` and `height` (they're plain SVGs on a 24×24 grid and accept any SVG attribute).
- They draw in the current text color.
- They cover the common controls. For anything else, use your own icon set (any 24×24 line icons, such as Lucide, match). These aren't meant to grow into a full library.

## Accessibility

The icons are `aria-hidden`. Name the control that contains them with an `aria-label` or visible text.
