# RevealImage

An image scanned onto the screen top to bottom by a glowing line, settling out of the theme tint.

```tsx
<RevealImage src="/orbit.jpg" alt="Orbit gameplay" ratio="4/3" caption="Orbit, 2026" />
<RevealImage src="/orbit.jpg" alt="" ratio={1.5} duotone />
<RevealImage src="/orbit.jpg" alt="Play Orbit" ratio="16/9" href="/games/orbit" />
<RevealImage ratio="1/1"><video src="/demo.mp4" autoPlay muted loop playsInline /></RevealImage>
```

Other attributes (`src`, `srcSet`, `sizes`, `loading`, …) go to the `<img>`.

## When to use

- Project images, portraits and screenshots that are part of the story of a page.
- Always set `ratio`, so the frame keeps its space while the image loads and the page doesn't jump.
- `duotone` keeps the image tinted in the theme hue. Use it for a set of mixed images that should look like one series.
- `href` makes the image a link; its frame lights up on hover and focus. A `RevealImage` placed directly inside your own `<a>` gets the same style.
- Pass custom media (video, SVG, canvas) as `children` instead of `src`.
- Don't use it for icons, logos or small thumbnails.

## States

- **Before view:** hidden.
- **Revealing:** a glowing line scans down, the image settles in brightness and the tint fades (unless `duotone`).
- **Linked, hover or focus:** a frame with the small glow.
- **Reduced motion:** appears without the scan.

## Accessibility

Write `alt` for what the image shows, or `alt=""` if it's decorative. As a link, `alt` is the link text, so say where it goes ("Play Orbit"). The caption is a real `<figcaption>`.

## Props

<!-- props:RevealImage -->
| Prop | Type | Default | Description |
| --- | --- | --- | --- |
| `ratio` | `string \| number` |  | Aspect ratio of the frame, e.g. "4/5" or 1.5. |
| `duotone` | `boolean` |  | Keep the image tinted in the theme hue after it appears. |
| `caption` | `ReactNode` |  | Text under the image, in a `<figcaption>`. |
| `delay` | `number` | `0` | ms to wait after it comes into view before the scan starts. |
| `duration` | `number` | `1300` | ms the scan takes. The image settles and the tint fades a little after that. |
| `offset` | `RevealOffset` | `--glow-reveal-offset` (25%) | How high it must scroll before it reveals. See `RevealOptions.offset`. |
| `children` | `ReactNode` |  | Custom media (SVG, video, canvas…) instead of `src`. |
| `href` | `string` |  | Wraps the figure in a link. The frame lights up on hover and focus. |
| `linkProps` | `Omit<AnchorHTMLAttributes<HTMLAnchorElement>, 'href'>` |  | Extra attributes for the link, e.g. `target`, `rel` or `aria-label`. |

`className` and `style` are passed to the root element. Also accepts the standard HTML attributes of `<img>`.

`RevealOffset`: see [motion/reveal.md](reveal.md).
<!-- /props -->
