# Reveal on scroll

Content animates in when it scrolls about a quarter of the way up the viewport. Every layout and type component takes `reveal` and `stagger`, and `Reveal` wraps anything else.

```tsx
<Heading reveal="rise">Selected work</Heading>
<Text reveal={{ effect: 'blur', delay: 300 }}>…</Text>
<Grid as="ol" reveal="rise" stagger={120}>…</Grid>   {/* each child enters in turn */}

<Reveal effect="scan"><MyCanvas /></Reveal>
<Stagger effect="fade" as="ul">…</Stagger>        {/* Reveal with stagger on */}
```

- `reveal` takes an effect name, or `{ effect, delay, duration, once, offset }` (see `RevealOptions` below).
- `stagger`: `true` animates the direct children 80ms apart, a number sets the gap in ms.
- Effects: `rise` · `fade` · `blur` · `ignite` · `wipe` · `scan`.

## When to use

- Reveal the parts of a page that tell its story: section headings, the first paragraph, a grid of projects. Leave controls, navigation and long body text static.
- `rise` is the calm default. `ignite` and `scan` are loud: at most once per page.
- Stagger lists and grids instead of giving each item its own `delay`.
- Keep delays short (under 500ms). Nobody waits for content they've scrolled to.
- To reveal earlier or later, change `--glow-reveal-offset` for the whole page, or `offset` for one element (a number is a % of the viewport height).
- Content near the end of the page that can't scroll that high reveals once the page is scrolled to the bottom.

## States

Hidden until it reaches the reveal line, then animates once. With `prefers-reduced-motion` it appears without animating. Animations leave no transform or filter behind once they finish.

Content waiting to reveal starts hidden, so with server rendering it stays invisible until the page hydrates (planned fix: 0.4.0).

## Your own components

`useReveal` wires any element up the same way. Spread `attrs`, merge `style`, attach `ref`:

```tsx
function Project(props) {
  const r = useReveal<HTMLElement>('rise', true);
  return <article ref={r.ref} {...r.attrs} style={r.style}>…</article>;
}
```

`useInView(ref, options)` just returns `true` once the element has reached the reveal line, for effects you run yourself (start a video, a canvas animation).

## Props

### Reveal (and Stagger)

<!-- props:Reveal -->
| Prop | Type | Default | Description |
| --- | --- | --- | --- |
| `as` | `ElementType` | `'div'` | The element to render. |
| `effect` | `RevealEffect` | `'rise'` | `rise` slides up · `fade` · `blur` comes into focus · `ignite` flickers on like neon · `wipe` uncovers from the left · `scan` uncovers from the top. |
| `delay` | `number` | `0` | ms to wait after it comes into view before it starts. |
| `duration` | `number` | `1000` (`1200` for ignite) | ms the animation takes (per child with `stagger`). |
| `once` | `boolean` | `true` | Animate only the first time it scrolls into view. `false` replays it each time it comes back. |
| `offset` | `RevealOffset` | `--glow-reveal-offset` (25%) | How high the element must scroll before it reveals. See `RevealOptions.offset`. |
| `stagger` | `StaggerProp` |  | Animate direct children one after another instead of the wrapper. |

`className` and `style` are passed to the root element. Also accepts the standard HTML attributes of the rendered element.

Types used above:

```ts
type RevealEffect = 'fade' | 'rise' | 'blur' | 'ignite' | 'wipe' | 'scan';

type RevealOffset = number | string;

/** `true` = 80ms between children, a number = custom ms step. */
type StaggerProp = boolean | number | undefined;
```
<!-- /props -->

### RevealOptions

The object form of the `reveal` prop and of `useReveal`'s first argument.

<!-- props:RevealOptions -->
| Prop | Type | Default | Description |
| --- | --- | --- | --- |
| `effect` | `RevealEffect` | required | `rise` slides up · `fade` · `blur` comes into focus · `ignite` flickers on like neon · `wipe` uncovers from the left · `scan` uncovers from the top. |
| `delay` | `number` | `0` | ms to wait after it comes into view before it starts. |
| `duration` | `number` | `1000` (`1200` for ignite) | ms the animation takes (per child with `stagger`). |
| `once` | `boolean` | `true` | Animate only the first time it scrolls into view. `false` replays it each time it comes back. |
| `offset` | `RevealOffset` | `--glow-reveal-offset` (25%) | How far above the bottom of the viewport the element's top must be before it reveals. A number is a percentage of the viewport height, a string any `rootMargin` length (`'25%'`, `'120px'`). |
<!-- /props -->

### InViewOptions

The options of `useInView`.

<!-- props:InViewOptions -->
| Prop | Type | Default | Description |
| --- | --- | --- | --- |
| `enabled` | `boolean` | `true` | `false` turns observing off and leaves the result `false`. |
| `once` | `boolean` | `true` | Stay `true` once it has been in view. `false` goes back to `false` when it leaves. |
| `offset` | `RevealOffset` | `--glow-reveal-offset` (25%) | See `RevealOptions.offset`. Ignored when `rootMargin` is set. |
| `rootMargin` | `string` |  | Full IntersectionObserver `rootMargin`, overriding `offset`. |
<!-- /props -->
