# Counter

A number that counts up when it scrolls into view, glowing while it runs.

```tsx
<Numeral><Counter to={1958} grouping={false} /></Numeral>   {/* a year */}
<Numeral tone="glow"><Counter to={98.6} decimals={1} format={(v) => `${v}%`} /></Numeral>
<Text>Played <Counter to={12400} /> times</Text>
```

## When to use

- A few key figures: years, totals, percentages, usually inside a `Numeral`.
- One counting animation per screen is plenty. For a table of numbers, just show them.
- `grouping={false}` for years, so 1958 doesn't become 1,958.
- `format` for units and prefixes. It receives the value already rounded to `decimals`.
- Numbers are formatted for the visitor's locale (separators and decimal point).

## Accessibility

Screen readers get the final value immediately; the counting digits are `aria-hidden`. With `prefers-reduced-motion` it shows the final value without counting.

## Props

<!-- props:Counter -->
| Prop | Type | Default | Description |
| --- | --- | --- | --- |
| `to` | `number` | required | The final number. Screen readers get this value straight away. |
| `from` | `number` | `0` | The number it counts up from. |
| `duration` | `number` | `1800` | ms the count takes. It eases out, slowing down near the end. |
| `delay` | `number` | `0` | ms to wait after it comes into view before counting. |
| `decimals` | `number` | `0` | Digits after the decimal point. |
| `grouping` | `boolean` | `true` | Thousands separators (default true). Turn off for years. |
| `format` | `(value: number) => ReactNode` |  | Custom formatting, e.g. v => `${v}%`. Receives the already rounded value. |
| `offset` | `RevealOffset` | `--glow-reveal-offset` (25%) | How high it must scroll before it reveals. See `RevealOptions.offset`. |

`className` is passed to the root element.

`RevealOffset`: see [motion/reveal.md](reveal.md).
<!-- /props -->
