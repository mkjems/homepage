# Rule

A horizontal line that draws itself in from the left, led by a glowing point of light.

```tsx
<Rule />                              {/* neon, draws in when scrolled into view */}
<Rule tone="line" weight={2} />
<Rule tone="hairline" reveal={false} />

<Stack gap={2}>                        {/* pipeline steps, drawn in turn */}
  <Rule delay={0} />
  <Rule delay={200} />
  <Rule delay={400} />
</Stack>
```

## When to use

- Section dividers on a Swiss-style page: above an eyebrow, between rows of a list.
- `neon` for the divider that opens a key section. `line` for strong structure, `hairline` for quiet separation.
- Several rules in sequence: step `delay` by about 200ms.
- Inside cards and dense UI, use the static `Divider` instead.

## Accessibility

Decorative: rendered with `role="presentation"`, so screen readers skip it. With `prefers-reduced-motion` it appears already drawn.

## Props

<!-- props:Rule -->
| Prop | Type | Default | Description |
| --- | --- | --- | --- |
| `tone` | `'neon' \| 'line' \| 'hairline'` | `'neon'` | `neon` glowing line · `line` solid white · `hairline` faint separator. |
| `weight` | `number` | `1` | Thickness in px. |
| `reveal` | `boolean` | `true` | Draw itself in from the left when scrolled into view. `false` shows it straight away. |
| `delay` | `number` | `0` | ms to wait after it comes into view before drawing. Use steps (0, 200, 400) to draw several rules in turn. |
| `duration` | `number` | `1400` | ms the line takes to draw. |
| `offset` | `RevealOffset` | `--glow-reveal-offset` (25%) | How high it must scroll before it reveals. See `RevealOptions.offset`. |

`className` and `style` are passed to the root element.

`RevealOffset`: see [motion/reveal.md](reveal.md).
<!-- /props -->
