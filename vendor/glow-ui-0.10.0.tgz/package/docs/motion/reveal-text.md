# RevealText

A headline that animates in word by word or letter by letter when it scrolls into view.

```tsx
<Heading size="display">
  <RevealText>Order made of light.</RevealText>
</Heading>

<Heading size="xl">
  <RevealText lines={['Games for', 'the browser.']} />
</Heading>

<Heading size="l">
  <RevealText parts={['One small server.', { text: 'Shipped on every push.', tone: 'muted' }]} />
</Heading>

<Heading size="xl" tone="glow">
  <RevealText effect="ignite">Letters flicker on.</RevealText>
</Heading>
```

Put it inside a `Heading` (or `Text`). `RevealText` animates, the parent sets size and tone.

## Effects

| Effect | Splits by | Feel |
| --- | --- | --- |
| `rise` (default) | words | words slide up out of a mask. Calm, the safe choice. |
| `fade` / `blur` | words | soft, for secondary lines |
| `ignite` | letters | letters flicker on like neon. Pair with `tone="glow"`. |
| `decode` | letters | letters resolve out of glowing noise. Short text only. |

Override the split with `split="words" | "chars"`, and the pace with `step` (ms between units; default 90 for words, 32 for letters).

## When to use

- The one or two most important headlines on a page. For other text, use the `reveal` prop on `Heading` or `Text`, which animates the whole element at once.
- A heading over several lines: pass `lines`. Each line starts on its own row and the stagger continues from line to line. Don't use two `RevealText`s with a `<br />` and hand-picked delays.
- A heading with a second tone: pass `parts`. Each part is a string or `{ text, tone?, break? }`. Parts on the same row are joined with a space and wrap like one sentence. `break: true` starts a part on a new row. `lines={['a', 'b']}` is the same as `parts` with `break: true` on every part.
- `ignite` and `decode` are loud: at most once per page.
- `delay` (ms) to follow something else that animates first. `offset` to reveal earlier or later than the page default (see [reveal.md](reveal.md)).

## States

Hidden until it reaches the reveal line, then animates once (`once={false}` replays it each time it re-enters). With `prefers-reduced-motion` the text appears at once.

## Accessibility

The full text is on the element as `aria-label` and the animated pieces are `aria-hidden`, so screen readers read it as one phrase. Pass a plain string as `children` (or strings in `lines` or `parts`), not elements. With `parts`, the label is the parts joined with spaces.

## Props

<!-- props:RevealText -->
| Prop | Type | Default | Description |
| --- | --- | --- | --- |
| `children` | `string` |  | The text. Use `lines` or `parts` instead for a heading built from several pieces. |
| `lines` | `string[]` |  | One entry per line. Each line starts on its own row and continues the stagger of the line before. Shorthand for `parts` where every part has `break: true`. |
| `parts` | `RevealTextPart[]` |  | Segments that continue one stagger. Each is a string or `{ text, tone?, break? }`: `tone` colors that segment, and `break: true` starts it on a new row. Segments on the same row are joined with a space. |
| `effect` | `TextEffect` | `'rise'` | `rise` words slide up out of a mask · `ignite` letters flicker on like neon · `decode` letters resolve out of glowing noise · `fade` / `blur`. |
| `split` | `'words' \| 'chars'` |  | Split into words or letters. Default: letters for ignite/decode, words otherwise. |
| `delay` | `number` | `0` | ms to wait after it comes into view before the first word or letter starts. |
| `step` | `number` | `90` for words, `32` for letters | ms between one word or letter and the next. |
| `duration` | `number` | `900` | ms each word or letter takes to animate in. |
| `once` | `boolean` | `true` | Animate only the first time it scrolls into view. `false` replays it each time it comes back. |
| `offset` | `RevealOffset` | `--glow-reveal-offset` (25%) | How high it must scroll before it reveals. A number is a percentage of the viewport height, a string any length (`'120px'`). |
| `as` | `ElementType` | `'span'` | The element to render. Inside a `Heading`, keep the default. |

`className` and `style` are passed to the root element.

Types used above:

```ts
/** One segment of a `RevealText` built from `parts`: a string, or an object with its own tone or a line break. */
type RevealTextPart =
  | string
  | {
      /** The text of this segment. */
      text: string;
      /** Text color for this segment, overriding the parent's tone. */
      tone?: Tone;
      /** Start this segment on a new row. */
      break?: boolean;
    };

type TextEffect = 'rise' | 'ignite' | 'fade' | 'blur' | 'decode';

type Tone = 'default' | 'muted' | 'faint' | 'glow';
```

`RevealOffset`: see [motion/reveal.md](reveal.md).
<!-- /props -->
