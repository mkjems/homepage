# List, ListItem

Index rows (title, detail, optional body) that cascade in. With `numbered`, each row gets a glowing 01, 02, 03.

```tsx
<List numbered>
  <ListItem title="Orbit" meta="2026" href="/games/orbit" />
  <ListItem title="Night Index" meta="2025" href="/games/night-index" />
  <ListItem title="Signal / Noise" meta="2024">
    <Text tone="muted" size="sm">An exhibition about static.</Text>
  </ListItem>
</List>
```

## When to use

- An index of projects, posts or talks: one line per item with a short detail on the right (`meta`: a year, a category).
- `numbered` when the order means something (steps, a ranking) or for the Swiss index look.
- `href` makes the whole row a link: it lights up on hover and keyboard focus. Pass `target` and `rel` through `linkProps`.
- Children go under the title, for a one-line description. Keep rows scannable.
- For data with several columns, use `Table`.

## States

- **Resting:** rows separated by hairlines.
- **Link row, hover or focus:** the title glows and the row lights up.
- **Revealing:** rows rise in one after another (90ms apart). Pass `reveal={false}` to show them straight away.

## Accessibility

Renders `<ul>`, or `<ol>` with `numbered`, so screen readers announce the count. With `href`, the title is the link text, so write titles that make sense on their own.

## Props

### List

<!-- props:List -->
| Prop | Type | Default | Description |
| --- | --- | --- | --- |
| `numbered` | `boolean` | `false` | Show glowing 01, 02, 03… numbers (renders an <ol>). |
| `reveal` | `RevealProp` | `'rise'` | Animation for the items; they enter one after another. Pass `false` to show them straight away. |
| `stagger` | `StaggerProp` | `90` | ms between one item and the next, or `true` for 80. |
| `children` | `ReactNode` | required | `ListItem`s. |

`className` and `style` are passed to the root element.

`RevealProp`, `StaggerProp`: see [motion/reveal.md](../motion/reveal.md).
<!-- /props -->

### ListItem

<!-- props:ListItem -->
| Prop | Type | Default | Description |
| --- | --- | --- | --- |
| `title` | `ReactNode` |  | Main text of the row. With `href`, it's the link text. |
| `meta` | `ReactNode` |  | Right-aligned detail, e.g. a year. |
| `href` | `string` |  | Makes the whole row a link. The title is the link text. |
| `linkProps` | `Omit<AnchorHTMLAttributes<HTMLAnchorElement>, 'href'>` |  | Extra attributes for the link, e.g. `target` and `rel`. |

`className` and `style` are passed to the root element. Also accepts the standard HTML attributes of the rendered element.
<!-- /props -->
