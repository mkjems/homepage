# Table

A data table from `columns` and `rows`. Rows cascade in, and the hovered row lights up.

```tsx
<Table
  caption="Selected projects"
  rowKey={(p) => p.slug}
  columns={[
    { key: 'year', header: 'Year', width: 80 },
    { key: 'title', header: 'Project', render: (p) => <a href={`/work/${p.slug}`}>{p.title}</a> },
    { key: 'pages', header: 'Pages', align: 'end' },
  ]}
  rows={projects}
/>
```

Each column shows `row[key]` unless it has a `render` function. The row type is inferred from `rows`, so `render` gets typed rows.

## When to use

- Data people compare across rows: several columns of the same kind of fact.
- Right-align numbers with `align: 'end'`.
- Pass `rowKey` when rows can change order or be added and removed.
- For a simple list with one detail per row, use `List`.
- On phones the table scrolls sideways inside its wrapper; keep it to 3–4 columns if it matters on mobile.

## States

- **Revealing:** rows rise in one after another (60ms apart). `reveal={false}` shows them straight away.
- **Hover:** the row lights up.

## Accessibility

A real `<table>` with `<th scope="col">` headers. Add a `caption` so screen reader users know what the table is about.

## Props

<!-- props:Table -->
| Prop | Type | Default | Description |
| --- | --- | --- | --- |
| `columns` | `TableColumn<T>[]` | required | The columns, in order. |
| `rows` | `T[]` | required | One object per row. `T` is your row type, inferred from this prop. |
| `rowKey` | `(row: T, index: number) => Key` | the row index | A stable key for each row. Pass it when rows can be added, removed or reordered. |
| `caption` | `ReactNode` |  | Table caption, read by screen readers and shown above the table. |
| `reveal` | `RevealProp` | `'rise'` | Rows enter one after another. Pass `false` to show them straight away. |
| `stagger` | `StaggerProp` | `60` | ms between one row and the next, or `true` for 80. |

`className` is passed to the root element.

Types used above:

```ts
interface TableColumn<T> {
  /** Property of the row to show, and the column's React key. */
  key: string;
  /** Text of the column header. */
  header: ReactNode;
  /** `end` right-aligns, e.g. numbers. */
  align?: 'start' | 'end';
  /** Column width: a number is px, a string any CSS width (`'40%'`). */
  width?: string | number;
  /** Custom cell. Defaults to row[key]. */
  render?: (row: T, index: number) => ReactNode;
}
```

`RevealProp`, `StaggerProp`: see [motion/reveal.md](../motion/reveal.md).
<!-- /props -->
