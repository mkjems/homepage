# Heading, Text, Eyebrow, Numeral

The type scale: flush left, ragged right, one strict set of sizes.

```tsx
<Eyebrow index="01">Selected work</Eyebrow>
<Heading level={1} size="display">Order made of light.</Heading>
<Text size="lg" tone="muted" measure>Games and experiments for the browser, built in public.</Text>
<Numeral tone="glow"><Counter to={1958} grouping={false} /></Numeral>
```

- `Heading`: Inter Tight. `level` sets the tag (`<h1>`…`<h6>`), `size` the look: `display` · `xl` · `l` · `m` · `s`. Without `size`, h1 is `xl`, h2 `l`, h3 `m`, h4–h6 `s`.
- `Text`: Inter, `size` `lg` · `md` · `sm` · `xs`. `measure` limits lines to about 62 characters.
- `Eyebrow`: small uppercase label above a heading, with an optional glowing `index` ("01").
- `Numeral`: an oversized figure for statistics and years.
- All four take `tone`: `default` · `muted` · `faint` · `glow`, and `reveal` to animate in.

## When to use

- Choose `level` for the document outline and `size` for the look. One `h1` per page, no skipped levels, even if an h2 should look like `display`.
- `display` once per page, for the hero. `xl` for section titles on a home page, `l` and `m` inside sections.
- `tone="glow"` is attention: use it on one heading or numeral per screen, not on body text.
- Body text longer than two lines gets `measure`.
- To animate a headline word by word, put a `RevealText` inside the `Heading`. The `reveal` prop animates the whole element at once.
- Tune the sizes with the `--glow-fs-*` tokens (see [theming.md](../theming.md)), not with `style`.

## Props

### Heading

<!-- props:Heading -->
| Prop | Type | Default | Description |
| --- | --- | --- | --- |
| `level` | `1 \| 2 \| 3 \| 4 \| 5 \| 6` | `2` | Heading level for the document outline: renders `<h1>`…`<h6>`. Pick it for structure, and `size` for the look. |
| `size` | `HeadingSize` |  | Visual size, independent of level. Defaults: h1 xl, h2 l, h3 m, h4+ s. |
| `as` | `ElementType` |  | The element to render, independent of the look. |
| `tone` | `Tone` | `'default'` | Text color: `muted` and `faint` step back, `glow` lights the text up in the theme hue. |
| `reveal` | `RevealProp` |  | Animate the whole element in when scrolled into view. For per-word or per-letter, use RevealText. |

`className` and `style` are passed to the root element. Also accepts the standard HTML attributes of the rendered element.

Types used above:

```ts
type HeadingSize = 'display' | 'xl' | 'l' | 'm' | 's';

type Tone = 'default' | 'muted' | 'faint' | 'glow';
```

`RevealProp`: see [motion/reveal.md](../motion/reveal.md).
<!-- /props -->

### Text

<!-- props:Text -->
| Prop | Type | Default | Description |
| --- | --- | --- | --- |
| `size` | `'lg' \| 'md' \| 'sm' \| 'xs'` | `'md'` | `lg` for intros and lead paragraphs, `md` for body text, `sm` for secondary text, `xs` for fine print. |
| `measure` | `boolean` |  | Limit line length to ~62 characters for comfortable reading. |
| `as` | `ElementType` | `'p'` | The element to render, independent of the look. |
| `tone` | `Tone` | `'default'` | Text color: `muted` and `faint` step back, `glow` lights the text up in the theme hue. |
| `reveal` | `RevealProp` |  | Animate the whole element in when scrolled into view. For per-word or per-letter, use RevealText. |

`className` and `style` are passed to the root element. Also accepts the standard HTML attributes of the rendered element.

`RevealProp`: see [motion/reveal.md](../motion/reveal.md).
<!-- /props -->

### Eyebrow

<!-- props:Eyebrow -->
| Prop | Type | Default | Description |
| --- | --- | --- | --- |
| `index` | `ReactNode` |  | A glowing index before the label, e.g. "01". |
| `as` | `ElementType` | `'p'` | The element to render, independent of the look. |
| `tone` | `Tone` | `'default'` | Text color: `muted` and `faint` step back, `glow` lights the text up in the theme hue. |
| `reveal` | `RevealProp` |  | Animate the whole element in when scrolled into view. For per-word or per-letter, use RevealText. |

`className` and `style` are passed to the root element. Also accepts the standard HTML attributes of the rendered element.

`RevealProp`: see [motion/reveal.md](../motion/reveal.md).
<!-- /props -->

### Numeral

<!-- props:Numeral -->
| Prop | Type | Default | Description |
| --- | --- | --- | --- |
| `as` | `ElementType` | `'div'` | The element to render, independent of the look. |
| `tone` | `Tone` | `'default'` | Text color: `muted` and `faint` step back, `glow` lights the text up in the theme hue. |
| `reveal` | `RevealProp` |  | Animate the whole element in when scrolled into view. For per-word or per-letter, use RevealText. |

`className` and `style` are passed to the root element. Also accepts the standard HTML attributes of the rendered element.

`RevealProp`: see [motion/reveal.md](../motion/reveal.md).
<!-- /props -->
