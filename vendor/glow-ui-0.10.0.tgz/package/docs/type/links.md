# Links

`glow-link` is a class for plain text links: in a nav, in a footer, or in a sentence. It is quiet at rest and glows on hover and keyboard focus, like every other control.

```tsx
<Inline as="nav" aria-label="Sections" gap={3}>
  <a className="glow-link" href="#work">Work</a>
  <a className="glow-link" href="#about">About</a>
</Inline>

<Text>
  Source on <a className="glow-link" href="https://github.com/…">GitHub</a>.
</Text>

<button type="button" className="glow-link" onClick={toggleGrid}>Press G</button>
```

## When to use

- Nav and footer links, and links inside text. For a call to action, use `Button href`. For a row in an index, use `ListItem href`.
- It works on `<button>` too, for text-style actions that aren't links, like "Show more" or "Press G". The class removes the button's own look.
- The look depends on the parent element, not on where the link sits on the page:
  - **Inside a `<p>` or `Text`**, the link keeps the color of the text around it and gets a hairline underline, so it isn't marked by color alone. This applies in a footer too: a footer line set with `Text size="xs" tone="faint"` gives its links the in-text look.
  - **Anywhere else**, for example directly in a nav or an `Inline`, the link is `--glow-text-muted` with no underline. Add a tone class (`glow-tone-faint`, `glow-tone-glow`) to change its resting color.
- The link takes its size from its parent (`font: inherit`). To make nav links smaller than body text, set the size on the nav with a type token, not by wrapping the links in `Text`, which would give them the in-text look: `<Inline as="nav" style={{ fontSize: 'var(--glow-fs-text-sm)' }}>`.

## States

| State | Look |
| --- | --- |
| Rest | muted, with no underline (outside text), or the text color with a hairline underline (inside a `<p>` or `Text`) |
| Hover | `--glow-core` with a `--glow-line` halo, and the underline lights up |
| Keyboard focus | the hover look plus a thin `--glow-line` outline |

## Accessibility

- Use `<a href>` for navigation and `<button>` for actions. The class only styles them.
- A nav of links goes in `Inline as="nav"` with an `aria-label`.
- The focus outline only shows for keyboard focus (`:focus-visible`), not on click.
