# Section

A page section with consistent vertical spacing.

```tsx
<Section id="work">
  <Container>
    <Grid>…</Grid>
  </Container>
</Section>

<Section padding="none">…</Section>   {/* full-bleed band, you handle the spacing */}
```

## When to use

- Wrap each top-level part of a page (hero, work, about, contact) in a `Section` so the space between them is the same everywhere: a fluid 64–144px, top and bottom.
- Put the `Container` inside the `Section`, so a section background can run edge to edge while the content keeps the page margins.
- Override with `padding` only for a deliberate change in rhythm, like a tighter hero (`padding={6}` is 48px).
- Renders a `<section>`. Start it with a heading. To make it a landmark screen reader users can jump to, also give it `aria-labelledby` pointing at that heading (or an `aria-label`).

## Props

<!-- props:Section -->
| Prop | Type | Default | Description |
| --- | --- | --- | --- |
| `padding` | `Space \| 'none'` | `clamp(64px, 10vw, 144px)` | Vertical padding, top and bottom: a spacing value, or `'none'`. |
| `reveal` | `RevealProp` |  | Animate in when scrolled into view. |
| `stagger` | `StaggerProp` |  | Animate direct children one after another (true = 80ms apart, or a number of ms). |
| `as` | `ElementType` | `'section'` | The element to render, e.g. `'section'`, `'ul'`, `'ol'`. |

`className` and `style` are passed to the root element. Also accepts the standard HTML attributes of the rendered element.

Types used above:

```ts
/** Spacing: a number is a multiple of the 8px unit; a string is used as-is. */
type Space = number | string;
```

`RevealProp`, `StaggerProp`: see [motion/reveal.md](../motion/reveal.md).
<!-- /props -->
