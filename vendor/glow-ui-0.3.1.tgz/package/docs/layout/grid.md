# Container, Grid, Col

The Swiss 12-column grid. Every page is built from these three.

```tsx
<Container>
  <Grid gapY={6}>
    <Col span={{ base: 12, lg: 3 }}>
      <Eyebrow index="01">Selected work</Eyebrow>
    </Col>
    <Col span={{ base: 12, lg: 9 }}>
      <Heading level={2}>Games for the browser.</Heading>
    </Col>
  </Grid>
</Container>
```

- `Container`: page margins (`--glow-margin`) and max width (`--glow-container`, 1360px).
- `Grid`: 12 columns by default (`columns`), with the system gutter.
- `Col`: `span` (a number or `'full'`), `start` (1-based column line), `align`.

## Responsive props

A plain value applies everywhere. `{ base, md, lg }` changes it at md ≥ 768px and lg ≥ 1100px. A breakpoint you leave out inherits the one below it.

```tsx
<Col span={{ base: 12, md: 6, lg: 4 }}>…</Col>   {/* 1 → 2 → 3 per row */}
<Col span={{ base: 12, lg: 8 }} start={{ lg: 5 }}>…</Col>   {/* pushed right on desktop */}
```

## When to use

- Labels in a narrow column, content in a wide one: `3 + 9` or `2 + 10` on `lg`, both `12` on `base`.
- Always start from `base: 12` on phones unless items are genuinely small (badges, stats).
- Use `start` to leave empty columns. Asymmetry and white space are the point of the Swiss grid.
- `Section` around a `Container` gives consistent vertical rhythm between page sections.
- `Stack` (column) and `Inline` (wrapping row) for arrangements inside a column. Don't nest a `Grid` just to put two buttons side by side.
- Spacing (`gap`, `gapX`, `gapY`) is a multiple of 8px: `gapY={6}` is 48px. A string such as `'2rem'` is used as is.
- `Grid as="ol"` with `stagger` makes a semantic list whose items animate in turn.

## Checking the layout

`GridOverlay` with `useGridToggle('g')` draws the columns as glowing lines. Press G to toggle it.

```tsx
const [grid] = useGridToggle('g');
<GridOverlay visible={grid} />
```

## Props

### Container

<!-- props:Container -->
| Prop | Type | Default | Description |
| --- | --- | --- | --- |
| `reveal` | `RevealProp` |  | Animate in when scrolled into view. |
| `stagger` | `StaggerProp` |  | Animate direct children one after another (true = 80ms apart, or a number of ms). |
| `as` | `ElementType` | `'div'` | The element to render, e.g. `'section'`, `'ul'`, `'ol'`. |

`className` and `style` are passed to the root element. Also accepts the standard HTML attributes of the rendered element.

`RevealProp`, `StaggerProp`: see [motion/reveal.md](../motion/reveal.md).
<!-- /props -->

### Grid

<!-- props:Grid -->
| Prop | Type | Default | Description |
| --- | --- | --- | --- |
| `columns` | `Responsive<number>` | `12` | Number of columns. Responsive. |
| `gap` | `Space` | `--glow-gutter` (16–24px) | Gap between columns and between rows. |
| `gapX` | `Space` |  | Gap between columns only. Overrides `gap`. |
| `gapY` | `Space` |  | Gap between rows only. Overrides `gap`. |
| `align` | `CSSProperties['alignItems']` |  | Vertical alignment of items in their row: `'start'`, `'center'`, `'end'`, `'baseline'` or `'stretch'` (CSS `align-items`). |
| `reveal` | `RevealProp` |  | Animate in when scrolled into view. |
| `stagger` | `StaggerProp` |  | Animate direct children one after another (true = 80ms apart, or a number of ms). |
| `as` | `ElementType` | `'div'` | The element to render, e.g. `'section'`, `'ul'`, `'ol'`. |

`className` and `style` are passed to the root element. Also accepts the standard HTML attributes of the rendered element.

Types used above:

```ts
type Responsive<T> = T | Partial<Record<Breakpoint, T>>;

/** Spacing: a number is a multiple of the 8px unit; a string is used as-is. */
type Space = number | string;

type Breakpoint = 'base' | 'md' | 'lg';
```

`RevealProp`, `StaggerProp`: see [motion/reveal.md](../motion/reveal.md).
<!-- /props -->

### GridOverlay

<!-- props:GridOverlay -->
| Prop | Type | Default | Description |
| --- | --- | --- | --- |
| `visible` | `boolean` | required | Show the overlay. Usually the state from `useGridToggle`. |
| `columns` | `number` | `12` | Match this to the Grid you're checking. |
| `baseline` | `boolean` | `true` | Also draw baseline rows (every --glow-baseline). |
<!-- /props -->

### Col

<!-- props:Col -->
| Prop | Type | Default | Description |
| --- | --- | --- | --- |
| `span` | `Responsive<number \| 'full'>` | `'full'` | Columns to span, or `'full'` for the whole row. Responsive: `span={{ base: 12, md: 6, lg: 4 }}`. |
| `start` | `Responsive<number>` |  | Column line to start on (1-based), leaving the columns before it empty. Responsive. Without it, columns flow left to right. |
| `align` | `CSSProperties['alignSelf']` |  | Vertical alignment of this item in its row, overriding the Grid's `align` (CSS `align-self`). |
| `reveal` | `RevealProp` |  | Animate in when scrolled into view. |
| `stagger` | `StaggerProp` |  | Animate direct children one after another (true = 80ms apart, or a number of ms). |
| `as` | `ElementType` | `'div'` | The element to render, e.g. `'section'`, `'ul'`, `'ol'`. |

`className` and `style` are passed to the root element. Also accepts the standard HTML attributes of the rendered element.

`RevealProp`, `StaggerProp`: see [motion/reveal.md](../motion/reveal.md).
<!-- /props -->
