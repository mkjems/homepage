# Glow UI docs

Short guides for using Glow UI, written for people and AI assistants alike. These files ship in the package, at `node_modules/glow-ui/docs/`.

**Start with [principles.md](principles.md).** It explains the few rules that the rest of the docs assume.

## Pages

**Basics:** [principles.md](principles.md) (start here) · [theming.md](theming.md) (hue, tokens, utility classes)

| Area | Page | Covers |
| --- | --- | --- |
| Controls | [components/button.md](components/button.md) | `Button` |
| | [components/menu.md](components/menu.md) | `Menu` |
| | [components/select.md](components/select.md) | `Select` |
| | [components/input.md](components/input.md) | `Input`, `Textarea` |
| | [components/toggles.md](components/toggles.md) | `Checkbox`, `Switch`, `RadioGroup` |
| | [components/slider.md](components/slider.md) | `Slider` |
| | [components/tabs.md](components/tabs.md) | `Tabs` |
| | [components/tooltip.md](components/tooltip.md) | `Tooltip` |
| | [components/dialog.md](components/dialog.md) | `Dialog` |
| | [components/card.md](components/card.md) | `Card`, `Divider` |
| | [components/badge.md](components/badge.md) | `Badge` |
| | [components/icons.md](components/icons.md) | `PlusIcon`, `SearchIcon`, … |
| Layout | [layout/grid.md](layout/grid.md) | `Container`, `Grid`, `Col`, `GridOverlay`, `useGridToggle` |
| | [layout/stack-inline.md](layout/stack-inline.md) | `Stack`, `Inline` |
| | [layout/section.md](layout/section.md) | `Section` |
| Type | [type/typography.md](type/typography.md) | `Heading`, `Text`, `Eyebrow`, `Numeral` |
| Motion | [motion/reveal.md](motion/reveal.md) | `reveal` / `stagger` props, `Reveal`, `Stagger`, `useReveal`, `useInView` |
| | [motion/reveal-text.md](motion/reveal-text.md) | `RevealText` |
| | [motion/reveal-image.md](motion/reveal-image.md) | `RevealImage` |
| | [motion/rule.md](motion/rule.md) | `Rule` |
| | [motion/counter.md](motion/counter.md) | `Counter` |
| Content | [content/list.md](content/list.md) | `List`, `ListItem` |
| | [content/table.md](content/table.md) | `Table` |

## Where things are

- **Props:** the table at the end of each page, generated from the TypeScript source so it always matches the code.
- **When and how to use something:** these pages.
- **What changed between versions:** [CHANGELOG.md](../CHANGELOG.md), with migration notes for each release.
- **Live examples:** the playground (`npm run dev` in the glow-ui repo).

## Writing a page

Every component page uses the same sections, in this order. Leave out a section that has nothing to say.

````md
# ComponentName

One sentence: what it is.

```tsx
// The smallest realistic example. Two or three variants at most.
```

## When to use
- Rules, one per line. Say which option to pick, not only what exists.
- End with the common mistake: "Don't …, use … instead."

## States
What it looks like resting, hovered, focused, open, disabled. Which states glow.

## Accessibility
What the component handles, and what the caller must still provide.

## Props

<!-- props:ComponentName -->
<!-- /props -->
````

Keep the hand-written part under about 60 lines. Prefer an example to a paragraph, and a rule to an explanation.

### Props tables are generated

Never write a props table by hand. `npm run docs` (also part of `npm run build`) fills every `<!-- props:Name -->` block from the component's props interface:

- **Description:** the prop's doc comment in the source. A prop without one gets an empty cell, so write the comment there, not in the page.
- **Default:** the `@default` tag if present, otherwise the default in the component's destructuring (`{ variant = 'quiet' }`). Use `@default` when the default lives in CSS (`@default 12`).
- **Types:** the Glow UI types a prop uses (`Space`, `Responsive`, `SelectOption`, …) are printed below the table.

`npm run docs:check` fails if a table is out of date.
