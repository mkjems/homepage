# Glow UI

A React design system of frosted-glass surfaces with neon edges. Resting controls stay quiet. The glowing edge and the halo that lights up the background are reserved for whatever has attention: focused, open, checked, or primary.

## Use it in another project

Build a tarball and install it. This avoids the duplicate-React problems a symlinked `npm link` can cause.

```bash
cd glow-ui
npm run pack                   # builds and writes glow-ui-<version>.tgz
cd ../my-app
npm install ../glow-ui/glow-ui-0.3.1.tgz
```

Each release has its own version and file name, so installing a new one always updates the lockfile. See `CHANGELOG.md` for what changed.

Then import the stylesheet once and use the components:

```tsx
import 'glow-ui/styles.css';
import { Select, Button } from 'glow-ui';

<body className="glow-root">  {/* black background, font, text color */}

<Select
  label="Viewport"
  defaultValue="tablet"
  options={[
    { value: 'tablet', label: 'Tablet', hint: '810' },
    { value: 'phone', label: 'Phone', hint: '390' },
    { separator: true },
    { value: 'custom', label: 'Custom…' },
  ]}
  onChange={(v) => console.log(v)}
/>
```

The look is tuned for Inter (text) and Inter Tight (headlines). The font files aren't bundled. The simplest way to self-host them is the optional `glow-ui/fonts.css`, which loads the right weights from `@fontsource`:

```bash
npm install @fontsource/inter @fontsource/inter-tight
```

```tsx
import 'glow-ui/fonts.css';
import 'glow-ui/styles.css';
```

Or load them from Google Fonts in your `<head>`:

```html
<link rel="preconnect" href="https://fonts.googleapis.com" />
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin />
<link
  rel="stylesheet"
  href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700&family=Inter+Tight:wght@500;600;700&display=swap"
/>
```

Or set `--glow-font` and `--glow-font-display` to other fonts.

## Docs

Short guides live in [`docs/`](docs/README.md) and ship with the package (`node_modules/glow-ui/docs/`). Start with [principles](docs/principles.md): glow means attention, color from one hue, and which CSS is public. Exact props are in `dist/index.d.ts`, and every release's changes and migration notes are in [`CHANGELOG.md`](CHANGELOG.md).

## Components

| Component                          | Notes                                                                                                 |
| ---------------------------------- | ----------------------------------------------------------------------------------------------------- |
| `Select`                           | Listbox with grow-in animation, separators, hints, disabled options, type-ahead, `variant="ghost"`    |
| `Menu`                             | Action menu on a button; trigger dims while open                                                      |
| `Button`                           | `glow` · `outline` · `quiet` · `ghost`; `sm` / `md` / `lg`; `icon` for square; `href` renders an `<a>` |
| `Input`, `Textarea`                | Label, hint, error, leading/trailing adornments, `sweep`; `Textarea bare` for composing inside a Card |
| `Checkbox`, `Switch`, `RadioGroup` | Native inputs underneath, so forms and screen readers work                                            |
| `Slider`                           | Native range with a neon fill                                                                         |
| `Tabs`                             | Arrow-key navigation, automatic activation                                                            |
| `Tooltip`                          | Shows on hover (with delay) and focus                                                                 |
| `Dialog`                           | Native `<dialog>`: focus trap, Esc, backdrop click                                                    |
| `Card`, `Divider`                  | `glow="none" \| "soft" \| "full"`, `sweep`, `hue`                                                     |
| `Badge`                            | `glow` / `quiet`, tones `success` · `warning` · `danger`, status `dot`                                |

Icons (`PlusIcon`, `ChevronDownIcon`, `ArrowUpIcon`, …) are exported too.

## Layout: the Swiss grid

A 12-column modular grid with fixed margins and gutters, following Josef Müller-Brockmann's grid systems. Breakpoints: `md` ≥ 768px, `lg` ≥ 1100px. Any responsive prop takes a plain value or `{ base, md, lg }`; a breakpoint left out inherits from the one below it.

```tsx
<Container>
  <Grid gapY={6}>
    <Col span={{ base: 12, lg: 2 }}>
      <Eyebrow index="01">Manifesto</Eyebrow>
    </Col>
    <Col span={{ base: 12, lg: 10 }} start={{ lg: 3 }}>
      <Heading level={1} size="display">
        Order made of light.
      </Heading>
    </Col>
  </Grid>
</Container>
```

| Component                            | Notes                                                            |
| ------------------------------------ | ---------------------------------------------------------------- |
| `Container`                          | Page margins and max width (`--glow-margin`, `--glow-container`) |
| `Grid`                               | `columns` (default 12), `gap` / `gapX` / `gapY`, `align`         |
| `Col`                                | `span` (number or `'full'`), `start`, `align`                    |
| `Stack`, `Inline`                    | Flexbox column / wrapping row with `gap`, `align`, `justify`     |
| `Section`                            | Vertical rhythm (`padding`)                                      |
| `GridOverlay` + `useGridToggle('g')` | Shows the columns and baseline as glowing construction lines     |

Spacing values are multiples of the 8px unit (`gap={3}` = 24px), or any CSS string.

## Typography

`Heading` (`size`: `display` · `xl` · `l` · `m` · `s`, independent of `level`), `Text` (`size`: `lg` · `md` · `sm` · `xs`, `measure` for a ~62ch line), `Eyebrow` (uppercase label with a glowing `index`), `Numeral` (oversized figures). All take `tone`: `default` · `muted` · `faint` · `glow`.

Headlines use `--glow-font-display` (Inter Tight → Helvetica Neue). Load Inter Tight for the intended look.

The sizes are tokens, so you can tune the scale:

| Token | Used by | Default |
| --- | --- | --- |
| `--glow-fs-display` | `Heading size="display"` | `clamp(48px, 9vw, 136px)` |
| `--glow-fs-xl` | `Heading size="xl"` | `clamp(36px, 5.2vw, 76px)` |
| `--glow-fs-l` | `Heading size="l"` | `clamp(28px, 3.2vw, 46px)` |
| `--glow-fs-m` | `Heading size="m"` | `clamp(22px, 2.2vw, 30px)` |
| `--glow-fs-s` | `Heading size="s"` | `18px` |
| `--glow-fs-numeral` | `Numeral` | `clamp(56px, 8vw, 128px)` |
| `--glow-fs-text-lg` / `--glow-fs-text` / `--glow-fs-text-sm` / `--glow-fs-text-xs` | `Text size` | `clamp(18px, 1.6vw, 22px)` / `16px` / `14px` / `12px` |

## Motion: reveal on scroll

Non-interactive content animates in the first time it scrolls about a quarter of the way up the viewport. With `prefers-reduced-motion`, it simply appears.

Set how high with the `--glow-reveal-offset` token (default `25%`, read once when the page loads), or per element with `offset` (`reveal={{ effect: 'rise', offset: 10 }}`, or the `offset` prop of `Reveal`, `RevealText`, `RevealImage`, `Rule` and `Counter`). A number is a percentage of the viewport height; a string is any length such as `'120px'`. Content too close to the end of the page to ever get that high reveals once the page is scrolled to the bottom.

- **`reveal` / `stagger` props** on `Container`, `Grid`, `Col`, `Stack`, `Inline`, `Section`, `Heading`, `Text`, `Eyebrow`, `Numeral`. Effects: `fade` · `rise` · `blur` · `ignite` · `wipe` · `scan`.
  ```tsx
  <Grid reveal="rise" stagger={120}>…</Grid>              {/* each Col enters in turn */}
  <Text reveal={{ effect: 'blur', delay: 400 }}>…</Text>
  ```
- **`Reveal` / `Stagger`** wrap anything else.
- **`RevealText`** animates text word by word or letter by letter: `rise` (words slide up out of a mask), `ignite` (letters flicker on like neon), `decode` (letters resolve out of glowing noise), `fade`, `blur`.
  ```tsx
  <Heading size="display">
    <RevealText effect="ignite">light.</RevealText>
  </Heading>
  ```
  For a heading over several lines, pass `lines`. Each line starts on its own row and continues the stagger of the line before:
  ```tsx
  <Heading size="xl">
    <RevealText lines={['Games for', 'the browser.']} />
  </Heading>
  ```
- **`Rule`** draws a line led by a glowing point (`tone`: `neon` · `line` · `hairline`, `weight`).
- **`RevealImage`** scans an image in with a glowing line, settling out of the theme tint. Pass `duotone` to keep the tint, `ratio`, `caption`, or custom media as children. With `href` the image is a link whose frame lights up on hover and focus (a `RevealImage` placed directly inside your own `<a>` gets the same style).
- **`Counter`** counts up, glowing while it runs. Use `grouping={false}` for years.
- **`List` / `ListItem`**: index rows with glowing 01, 02, 03 numbering that cascade in. With `href` the whole row is a link:
  ```tsx
  <List numbered>
    <ListItem title="Orbit" meta="2026" href="/games/orbit" />
  </List>
  ```
- **`Table`**: data-driven (`columns`, `rows`); rows cascade in, and the hovered row lights up.
- **`useReveal` / `useInView`** hooks let your own components join in.

Content waiting to reveal is hidden until it scrolls into view. With server rendering it stays hidden until the page hydrates.

## Theming

Every color comes from a single hue:

```css
:root {
  --glow-h: 268;
} /* violet everything */
```

To retint just one part of the page, add the `glow-hue` class to an element and set `--glow-h` on it. Everything inside follows:

```tsx
<div className="glow-hue" style={{ '--glow-h': 150 } as React.CSSProperties}>…</div>
<Card hue={320}>…</Card>  {/* shorthand */}
```

`glow-danger`, `glow-success` and `glow-warning` are ready-made hue classes.

Other tokens: `--glow-font`, `--glow-font-display`, `--glow-radius`, `--glow-radius-md`, `--glow-bg`, the `--glow-fs-*` type scale (see Typography) and `--glow-reveal-offset` (see Motion).

## Utility classes

For building your own glowing pieces:

- `glow-surface`: frosted glass panel
- `glow-lit`: full neon edge and room-lighting halo
- `glow-lit-sm`: tight glow
- `glow-sweep`: a light streak that travels around the border

## Develop

```bash
npm run dev        # playground at http://localhost:5173
npm run build      # dist/ (ESM + CJS + types + styles.css)
npm run typecheck
npm run pack       # glow-ui-<version>.tgz
```

To release: run `npm version minor --no-git-tag-version` (or `patch`), add the version's section to `CHANGELOG.md`, commit, then `npm run pack`. Planned releases are in `ROADMAP.md`.

Popovers are positioned under their trigger with CSS, with no portal. A parent with `overflow: hidden` will clip them.
