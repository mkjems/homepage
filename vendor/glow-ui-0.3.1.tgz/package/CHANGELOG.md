# Changelog

All notable changes to Glow UI. Glow UI is pre-1.0: a minor version (0.x.0) can contain breaking or visible changes, a patch (0.x.y) only fixes. Planned releases are in `ROADMAP.md`.

## 0.3.1

Documentation for every component, shipped in the package.

### Added

- `docs/`: usage guides for every component, shipped in the package at `node_modules/glow-ui/docs/`. Start with `docs/principles.md`; `docs/README.md` is the index, and `docs/theming.md` lists every token.
- Each page ends with a props table (type, default, description) generated from the TypeScript source, plus the definitions of the Glow UI types it uses.
- Doc comments, and `@default` where the default lives in CSS, for every public prop, so they also show up on hover in your editor.
- `CHANGELOG.md` now ships in the package.

### Changed

- `InlineProps` is an interface instead of a type alias. It accepts the same props.
- `--glow-font-display` moved next to `--glow-font` at the top of `styles.css`. Same value.

### Migrating from 0.3.0

- Install `glow-ui-0.3.1.tgz`. Nothing in your code needs to change.
- Point your AI assistant at `node_modules/glow-ui/docs/README.md`.

## 0.3.0

Calmer type and motion.

### Added

- Type scale tokens at the top of `styles.css`: `--glow-fs-display`, `--glow-fs-xl`, `--glow-fs-l`, `--glow-fs-m`, `--glow-fs-s`, `--glow-fs-numeral`, and `--glow-fs-text-lg` / `--glow-fs-text` / `--glow-fs-text-sm` / `--glow-fs-text-xs`. Override them to tune the scale.
- `--glow-reveal-offset` token (default `25%`) sets how far up the viewport content must scroll before it reveals. `useInView` reads it once per page.
- `offset` for a single element: in `reveal={{ effect, offset }}`, on `Reveal`, `RevealText`, `RevealImage`, `Rule` and `Counter`, and in `useInView` options. A number is a percentage of the viewport height, a string any length (`'120px'`).
- `RevealText lines={["Games for", "the browser."]}` puts each line on its own row and staggers through them in one sequence. Works with every effect, including `decode`.
- `glow-ui/fonts.css`: optional self-hosted Inter and Inter Tight via `@fontsource/inter` and `@fontsource/inter-tight`, which are optional peer dependencies.
- Exported types `RevealOffset` and `InViewOptions`.

### Changed

- Smaller large headings: display `clamp(48px, 9vw, 136px)` (was `clamp(56px, 11.5vw, 184px)`), xl `clamp(36px, 5.2vw, 76px)` (was `clamp(40px, 6.4vw, 96px)`), l `clamp(28px, 3.2vw, 46px)` (was `clamp(30px, 3.8vw, 56px)`). The m, s, numeral and text sizes are unchanged.
- Content reveals later: when its top is 25% above the bottom of the viewport (was 10%).
- Content near the end of the page that can never scroll that high now reveals when the page is scrolled to the bottom.
- `RevealText` `children` is optional when `lines` is given.

### Migrating from 0.2.0

- Install `glow-ui-0.3.0.tgz`.
- Headings are smaller. To keep the 0.2.0 sizes, set the old values on `:root`, for example `--glow-fs-display: clamp(56px, 11.5vw, 184px)`.
- To keep the earlier reveal timing, set `--glow-reveal-offset: 10%` on `:root`.
- Two `RevealText`s joined by a `<br />` with hand-picked delays can become one `RevealText lines={[…]}`.
- To use `glow-ui/fonts.css`, install `@fontsource/inter` and `@fontsource/inter-tight`, import it, and remove the Google Fonts `<link>`.

## 0.2.0

### Added

- `Button` takes `href` and then renders an `<a>` with the same look. Replaces hand-written `<a className="glow-btn glow-btn--outline">`.
- `ListItem` takes `href` (and `linkProps` for `target`, `rel` and so on). The whole row becomes clickable, and it lights up on hover and keyboard focus. The title is the link text.
- `RevealImage` takes `href` (and `linkProps`). The image gets a quiet frame that lights up with `--glow-shadow-sm` on hover and focus. The same style applies to any `RevealImage` placed directly inside an `<a>`.
- The README has the exact Google Fonts `<link>` tag for Inter and Inter Tight.
- `CHANGELOG.md` and `ROADMAP.md`.

### Changed

- `npm run pack` writes `glow-ui-<version>.tgz` instead of `glow-ui.tgz`. Each release has its own file name, so the consumer has to run `npm install` and its lockfile checksum stays correct.
- `.glow-btn` sets `text-decoration: none`.

### Migrating from 0.1.0

- Install the new tarball by its versioned name: `npm install path/to/glow-ui-0.2.0.tgz`.
- Hand-built link buttons, linked list rows and image-link hover styles can be replaced with the `href` props. Don't copy internal keyframes such as `glow-rise`; they aren't part of the API.

## 0.1.0

First version: controls (Select, Menu, Button, Input, Textarea, Checkbox, Switch, RadioGroup, Slider, Tabs, Tooltip, Dialog, Card, Badge), the Swiss grid (Container, Grid, Col, Stack, Inline, Section, GridOverlay), type (Heading, Text, Eyebrow, Numeral), scroll-reveal motion (Reveal, Stagger, RevealText, RevealImage, Rule, Counter, `useReveal`, `useInView`) and content (List, Table).
